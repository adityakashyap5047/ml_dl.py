import React from "react";
import {
  View,
  Text,
  Button,
  StyleSheet,
  Linking,
  TouchableOpacity,
  ImageBackground,
} from "react-native";

const TutorialScreen = ({ navigation }) => {
  // Add pictures, and/or videos
  const openIQuestWebsite = () => {
    Linking.openURL("https://www.gvsu.edu/autismcenter/passport-216.htm"); // Replace with the actual website URL
  };
  return (
    <ImageBackground
      source={require("../Images/bg.png")} // Replace with your actual image path
      style={styles.background}
    >
      <View style={styles.container}>
        <Text style={styles.title}>Tutorial - How to Use the iQuest</Text>

        <Text style={styles.instructions}>
          1. Directions are given on each slide.
        </Text>
        <Text style={styles.instructions}>
          2. You can use the menu in the top right corner of the slides to go
          from one slide to another.
        </Text>
        <Text style={styles.instructions}>
          3. On the goal slides, look at the goal ideas, and pick one or two
          goals.
        </Text>
        <Text style={styles.goalInstructions}>
          - Goals can come from one or more than one of the Goal Categories:
          Independence, Self-Advocacy and Self-Determination, Social, Safety,
          Health and Sexuality, Community.
        </Text>
        <Text style={styles.goalInstructions}>
          - To add more goals, copy the goal slide. Change the goal numbers to
          Goal 3 and 4. Repeat this step as many times as you need; changing the
          numbers each time.
        </Text>

        <TouchableOpacity onPress={openIQuestWebsite}>
          <Text style={styles.linkText}>
            For more information, visit the{" "}
            <Text style={styles.link}>iQuest website</Text>.
          </Text>
        </TouchableOpacity>

        <Button title="Next" onPress={() => navigation.navigate("MainPage")} />
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover", // You can change this to "contain" or other values based on your image requirements
  },
  container: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
  },
  instructions: {
    fontSize: 16,
    marginBottom: 10,
  },
  goalInstructions: {
    fontSize: 16,
    marginLeft: 20,
    marginBottom: 10,
  },
  linkText: {
    fontSize: 16,
    marginTop: 20,
  },
  link: {
    color: "blue",
    textDecorationLine: "underline",
  },
});

export default TutorialScreen;
