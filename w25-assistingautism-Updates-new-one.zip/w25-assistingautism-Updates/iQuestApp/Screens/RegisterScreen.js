import { useNavigation } from "@react-navigation/core";
import DateTimePicker from "@react-native-community/datetimepicker";
import React, { useEffect, useState } from "react";
import {
  auth,
  createUserWithEmailAndPassword,
  db,
  setDoc,
  doc,
} from "../firebase.js";

import {
  KeyboardAvoidingView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Image,
  TouchableWithoutFeedback,
  Keyboard,
} from "react-native";
import DropDownPicker from "react-native-dropdown-picker";

import defaultProfilePicture from "../Images/pp.png";
import { useTheme } from "../src/ThemeContext.js";
import { themeStyles } from "../src/styles.js";

const RegisterScreen = () => {
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const isURLImage =
    typeof backgroundImage === "string" && backgroundImage.startsWith("http");
  const [first, setFirst] = useState("");
  const [last, setLast] = useState("");
  const [firstPassword, setFirstPassword] = useState("");
  const [secondPassword, setSecondPassword] = useState("");
  const [email, setEmail] = useState("");
  const [born, setBorn] = useState(new Date()); // Initialize with current date
  const [showDatePicker, setShowDatePicker] = useState(Platform.OS === "ios");

  const [grade, setGrade] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const grades = [
    { label: "Kindergarten", value: "Kindergarten" },
    { label: "1st", value: "1st Grade" },
    { label: "2nd", value: "2nd Grade" },
    { label: "3rd", value: "3rd Grade" },
    { label: "4th", value: "4th Grade" },
    { label: "5th", value: "5th Grade" },
    { label: "6th", value: "6th Grade" },
    { label: "7th", value: "7th Grade" },
    { label: "8th", value: "8th Grade" },
    { label: "9th", value: "9th Grade" },
    { label: "10th", value: "10th Grade" },
    { label: "11th", value: "11th Grade" },
    { label: "12th", value: "12th Grade" },
    {
      label: "Post-Secondary School Program",
      value: "Post-Secondary School Program",
    },
    { label: "College/University", value: "College/University" },
    { label: "Not in School", value: "Not in School" },
    { label: "Other", value: "Other" },
  ];

  const formattedDate = born.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });

  const openDatePicker = () => {
    setShowDatePicker(true);
  };

  const onChange = (event, selectedDate) => {
    const currentDate = selectedDate || born;
    setShowDatePicker(Platform.OS === "ios"); // On iOS, show the modal again after selecting a date
    setBorn(currentDate);
  };

  const navigation = useNavigation();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        navigation.navigate("Home");
      }
    });

    return unsubscribe;
  }, []);

  const handleSignUp = async () => {
    const lowercaseEmail = email.toLowerCase();

    if (first != "") {
      if (last != "") {
        if (firstPassword == secondPassword) {
          try {
            // Create a user with Firebase Authentication
            const userCredential = await createUserWithEmailAndPassword(
              auth,
              lowercaseEmail,
              firstPassword
            );
            const user = userCredential.user;

            // Save user data to Firestore with the user's UID as the document ID
            const userDocRef = doc(db, "users", user.uid);
            await setDoc(userDocRef, {
              first: first,
              last: last,
              email: lowercaseEmail,
              grade: grade,
              born: born,
              background: "#dd05ff",
              text: "black",
              button: "#FFA500",
              home: 0,
              school: 0,
              //remove setPassword so we dont store their password in database for security.
              password: firstPassword,
              profilePicture: "",
              streak: 0,
            });

            console.log("Registered with:", user.email);
          } catch (error) {
            const errorCode = error.code;
            const errorMessage = error.message;
            console.error("Error:", errorMessage);

            // Custom Error Messages
            if (String(errorMessage).includes("missing-email")) {
              alert("Please Enter Email");
            } else if (String(errorMessage).includes("invalid-email")) {
              alert("Please Enter Valid Email Format");
            } else if (String(errorMessage).includes("weak-password")) {
              alert("Please Enter Password with at Least 6 Characters");
            } else if (String(errorMessage).includes("missing-password")) {
              alert("Please Enter Password");
            } else if (String(errorMessage).includes("email-already-in-use")) {
              alert(
                "Email Entered is Already in use\n Please Enter Another Email"
              );
            } else {
              alert(errorMessage);
            }
          }
        } else {
          alert("Passwords Do Not Match");
        }
      } else {
        alert("Please Enter Last Name");
      }
    } else {
      alert("Please Enter First Name");
    }
  };

  return (
    <View style={[bgStyles.container]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />

      <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
        <KeyboardAvoidingView style={styles.container} behavior="padding">
          <View style={styles.inputContainer}>
            <Text style={styles.title}>Register</Text>
            <View style={styles.textContainer}>
              <TextInput
                placeholder="First Name"
                value={first}
                onChangeText={(text) => setFirst(text)}
                style={styles.input}
              />
              <TextInput
                placeholder="Last Name"
                value={last}
                onChangeText={(text) => setLast(text)}
                style={styles.input}
              />

              <TextInput
                placeholder="Password"
                value={firstPassword}
                onChangeText={(text) => setFirstPassword(text)}
                style={styles.input}
                secureTextEntry
              />

              <TextInput
                placeholder="Confirm Password"
                value={secondPassword}
                onChangeText={(text) => setSecondPassword(text)}
                style={styles.input}
                secureTextEntry
              />

              <TextInput
                placeholder="Email"
                value={email}
                onChangeText={(text) => setEmail(text)}
                style={styles.input}
                keyboardType="email-address"
              />
            </View>
            <View style={styles.datePickerContainer}>
              <Text style={styles.datePickerLabel}>Choose your birthday:</Text>
              {Platform.OS === "android" && (
                <TouchableOpacity
                  onPress={openDatePicker}
                  style={styles.dateContainer}
                >
                  <Text style={styles.datePicker}>{formattedDate}</Text>
                </TouchableOpacity>
              )}
              {showDatePicker && (
                <DateTimePicker
                  value={born}
                  mode="date"
                  display="default"
                  onChange={onChange}
                  style={styles.datePicker}
                />
              )}
            </View>
            {/* temp fix - moving the grade after the birthday */}
            <View style={styles.row}>
              <Text style={styles.label}>Grade</Text>
              <View style={styles.pickerContainer}>
                <DropDownPicker
                  style={styles.pickerDrop}
                  items={grades}
                  open={isOpen}
                  setOpen={() => setIsOpen(!isOpen)}
                  value={grade}
                  setValue={(val) => setGrade(val)}
                  maxHeight={200}
                  dropDownDirection="BOTTOM" //temporary fix
                  placeholder="Select Grade"
                />
              </View>
            </View>

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                onPress={handleSignUp}
                style={[styles.button, styles.buttonOutline]}
              >
                <Text style={styles.buttonOutlineText}>Register</Text>
              </TouchableOpacity>
            </View>

            <View
              style={{
                opacity: Platform.OS === "android" ? 0 : 10,
                pointerEvents: Platform.OS === "android" ? "none" : "auto",
              }}
            >
              <View style={styles.backButtonContainer}>
                <TouchableOpacity onPress={() => navigation.navigate("Login")}>
                  <Text style={styles.buttonText}>Return to Login Screen</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </View>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover", // You can change this to "contain" or other values based on your image requirements
  },

  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  title: {
    backgroundColor: "#FFA500",
    fontSize: 40,
    width: 175,
    alignSelf: "center",
    fontWeight: "bold",
    textAlign: "center",
    padding: 5,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  inputContainer: {
    width: "80%",
  },

  textContainer: {
    marginTop: 25,
    width: "100%",
  },

  input: {
    backgroundColor: "#5A5A5A",
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 10,
    marginTop: 8,
    textAlign: "center",
    borderRadius: 5,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  datePickerContainer: {
    marginTop: 25,
    backgroundColor: "#5A5A5A",
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },
  datePickerLabel: {
    marginRight: 10,
    fontSize: 16,
    //fontWeight: "bold",
  },
  datePicker: {
    paddingVertical: 10,
    borderRadius: 10,
    fontSize: 16, // Adjust the font size as needed
    color: "black", // Adjust the text color as needed
    textAlign: "center", // Center the text horizontally
    // Add any other styles you want to customize
  },

  buttonContainer: {
    width: "60%",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 40,
    alignSelf: "center",
  },

  backButtonContainer: {
    width: "60%",
    top: "5%",
    //justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
  },

  button: {
    backgroundColor: "#0782F9",
    width: "100%",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
    marginBottom: 15,
  },

  buttonOutline: {
    backgroundColor: "white",
    marginTop: 5,
    borderColor: "#0782F9",
    borderWidth: 2,
  },

  buttonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },

  buttonOutlineText: {
    color: "#0782F9",
    fontWeight: "700",
    fontSize: 16,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
    zIndex: 999,
  },

  label: {
    flex: 1,
    backgroundColor: "#FFA500",
    textAlign: "center",
    fontSize: 20,
    fontWeight: "bold",
    marginRight: 8,
    marginLeft: 8,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },
  pickerDrop: {
    backgroundColor: "#5A5A5A",
  },
  pickerContainer: {
    width: "65%",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 10,
    zIndex: 999,
  },
});
