import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import React, { useEffect } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Image, StatusBar, } from "react-native";
import { useIsFocused } from "@react-navigation/native";
import { auth } from "../firebase";
import { useCategories } from "../src/CategoriesContext";
import { useUserPreferences } from "../src/UserPreferencesContext";
import { Platform } from "react-native";

const CategoriesScreen = ({ navigation }) => {
  //get background
  const { theme, backgroundImage } = useTheme();
  const { homeCategories, schoolCategories } = useCategories();
  const { userBackground, userButton, userText, fetchColors } = useUserPreferences();
  const bgStyles = themeStyles[theme];

  // reload page and queries
  const isFocused = useIsFocused();
  useEffect(() => {
    // Fetch data when the screen is focused or on component mount
    if (isFocused) {
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]); // Run when isFocused changes

  return (
    <View style={[bgStyles.container, { alignItems: "center", paddingTop: Platform.OS === 'ios' ? 40 : 0 }]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />

      <View style={[styles.labelContainer]}>
        <Text style={[styles.label, { backgroundColor: userButton, color: userText }]}>
          Home Independence Goals
        </Text>
      </View>

      <View style={styles.buttonContainer}>
        {homeCategories.map((category, index) => (
          <TouchableOpacity
            key={index}
            onPress={() =>
              navigation.navigate("GoalsScreen", {
                category,
                section: "Home",
              })
            }
            style={[
              styles.button,
              { backgroundColor: userButton },
              index < homeCategories.length ? {} : {},
            ]}
          >
            <Text style={[styles.buttonText, { color: userText }]}>{category}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={[styles.labelContainer2, {marginTop: Platform.OS === 'ios' ? '3%' : 0 }]}>
        <Text style={[styles.label, { backgroundColor: userButton, color: userText }]}>
          School Independence Goals
        </Text>
      </View>

      <View style={styles.buttonContainer}>
        {schoolCategories.map((category, index) => (
          <TouchableOpacity
            key={index}
            onPress={() =>
              navigation.navigate("GoalsScreen", {
                category,
                section: "School",
              })
            }
            style={[
              styles.button,
              { backgroundColor: userButton },
              index < schoolCategories.length ? {} : {},
            ]}
          >
            <Text style={[styles.buttonText, { color: userText }]}>{category}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity onPress={() => navigation.navigate("Home")}>
          <Text style={styles.backButtonText}> Return to Home Screen </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  buttonContainer: {
    width: "60%",
    alignSelf: "center",
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginBottom: '5%',
  },

  button: {
    backgroundColor: "#FFA500",
    width: "100%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    alignSelf: "center",
    marginTop: "2%",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
  },

  buttonText: {
    color: "black",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
  },

  labelContainer: {
    //backgroundColor: "white",
    height: "3%",
    marginTop: "8%",
    paddingBottom: 0,
    alignItems: "center",
  },

  labelContainer2: {
    //backgroundColor: "white",
    height: "3%",
    paddingBottom: 0,
    alignItems: "center",
  },

  label: {
    backgroundColor: "#FFA500",
    width: 350,
    height: 22,
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  backButton: {
    width: "100%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
  },

  backButtonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },
});

export default CategoriesScreen;
