import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Alert,
  Platform,
} from "react-native";
import logoutIcon from "../assets/logout.png";
import WelcomeMessage from "../src/WelcomeMessage";
import { auth, db, getDoc, doc, signOut } from "../firebase";
import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import { useIsFocused } from "@react-navigation/native";
import { useUserPreferences } from "../src/UserPreferencesContext";

const HomeScreen = ({ navigation }) => {
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  //const isURLImage = typeof backgroundImage === "string" && backgroundImage.startsWith("http");
  const { userBackground, userButton, userText, fetchColors } = useUserPreferences();

  const handleLogout = () =>
    Alert.alert("Logout?", "Are you sure you want to logout?", [
      {
        text: "Cancel",
        onPress: () => console.log("Cancel Pressed"),
        style: "cancel",
      },
      {
        text: "OK",
        onPress: () => {
          console.log("OK Pressed");
          handleSignOut();
        },
      },
    ]);

  const handleSignOut = () => {
    signOut(auth)
      .then(() => {
        console.log("Logged out");
        navigation.navigate("Login");
      })
      .catch((error) => {
        alert(error.message);
      });
  };


  // reload page and queries
  const isFocused = useIsFocused();
  useEffect(() => {
    // Fetch data when the screen is focused or on component mount
    if (isFocused) {
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]); // Run when isFocused changes

  return (
    <View style={[bgStyles.container, { backgroundColor: userBackground }]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />

      <View style={styles.header}>
        <TouchableOpacity onPress={handleLogout}>
          <View style={[styles.logoutIconContainer, { backgroundColor: userButton }]}>
            <Image source={logoutIcon} style={styles.logoutIcon} />
          </View>
        </TouchableOpacity>
      </View>

      <WelcomeMessage></WelcomeMessage>

      <View style={[styles.buttonContainer, { marginTop: 275 }]}>

        <TouchableOpacity
          onPress={() => navigation.navigate("ProfileScreen")}
          style={[styles.button, { backgroundColor: userButton }]} >
          <Text style={[styles.buttonText, { color: userText }]}> Profile </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => navigation.navigate("CategoriesScreen")}
          style={[styles.button, { backgroundColor: userButton }]} >
          <Text style={[styles.buttonText, { color: userText }]}> Add Independence Goal</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate("MyGoalsScreen")}
          style={[styles.button, { backgroundColor: userButton }]} >
          <Text style={[styles.buttonText, { color: userText }]}> My Independence Goals</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => navigation.navigate("SettingsScreen")}
          style={[styles.button, { backgroundColor: userButton }]}>
          <Text style={[styles.buttonText, { color: userText }]}> Settings </Text>
        </TouchableOpacity>

      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover", // You can change this to "contain" or other values based on your image requirements
  },
  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  buttonContainer: {
    width: "60%",
    alignSelf: "center",
    alignItems: "center",
    //paddingHorizontal: 10,
    paddingVertical: 10,
    // marginTop: 275,
    marginHorizontal: 75,
  },

  button: {
    backgroundColor: "#FFA500",
    width: "100%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
    marginTop: "20%",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
  },

  buttonText: {
    color: "black",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
  },

  settingsButton: {
    backgroundColor: "#0782F9",
    width: "100%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 150,
  },

  settingsButtonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
  },

  header: {
    flexDirection: "row",
    //justifyContent: "flex-start",
    alignItems: "center",
    padding: 20,
  },

  logoutIconContainer: {
    position: "absolute",
    marginTop: Platform.isPad? "5%" : "10%",
    marginLeft: "5%",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  logoutIcon: {
    height: Platform.isPad? "85%" :"100%",
    width: 30,
  },
});

export default HomeScreen;
