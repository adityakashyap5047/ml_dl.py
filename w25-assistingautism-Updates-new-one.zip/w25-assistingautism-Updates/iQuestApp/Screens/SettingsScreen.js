import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Linking,
} from "react-native";
import DropDownPicker from "react-native-dropdown-picker";
import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import { auth, db, getDoc, doc, updateDoc } from "../firebase";
import { useIsFocused } from "@react-navigation/native";
import { useUserPreferences } from "../src/UserPreferencesContext";

const SettingsScreen = ({ navigation }) => {
  const { theme, backgroundImage, changeBackgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const { userBackground, userButton, userText, fetchColors } =
    useUserPreferences();

  //const isURLImage = typeof backgroundImage === "string" && backgroundImage.startsWith("http");

  // reload page and queries
  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]);

  const [isOpen, setIsOpen] = useState(false);
  const [userId, setUserId] = useState(auth.currentUser?.uid); // Initialize with the UID
  const [currValue, setCurrValue] = useState();
  const backgroundItems = [
    { label: "Animals", value: "Animals" },
    { label: "Numbers", value: "Numbers" },
    { label: "Music", value: "Music" },
    { label: "Dinosaurs", value: "Dinosaurs" },
    { label: "Anime", value: "Anime" },
    { label: "Maps", value: "Maps" },
    { label: "Trains", value: "Trains" },
  ];

  const handleDropdownChange = async (value) => {
    try {
      setCurrValue(value);
      const userRef = doc(db, "users", userId);

      // Ensure that the value is a string before updating Firestore
      const validValue = typeof currValue === "string" ? currValue : null;

      await updateDoc(userRef, { backgroundChoice: validValue });
      changeBackgroundImage(validValue);
    } catch (error) {
      console.error("Error updating background choice: ", error);
    }
  };

  const handleYoutube = () => {
    // Replace 'YOUR_YOUTUBE_VIDEO_URL' with the actual URL of your YouTube video
    const youtubeVideoUrl = "https://www.youtube.com/watch?v=48yLKezKafE";

    // Open the YouTube video URL
    Linking.openURL(youtubeVideoUrl).catch((err) =>
      console.error("An error occurred: ", err)
    );
  };

  return (
    <View style={[bgStyles.container, { backgroundColor: userBackground }]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />

      <View style={styles.container}>
        <Text
          style={[
            styles.title,
            { backgroundColor: userButton, color: userText },
          ]}
        >
          Settings
        </Text>
      </View>

      {/*  Background Picker */}
      <View style={styles.pickerContainer}>
        <DropDownPicker
          items={backgroundItems}
          open={isOpen}
          setOpen={() => setIsOpen(!isOpen)}
          value={currValue}
          setValue={(val) => setCurrValue(val)}
          maxHeight={300}
          dropDownContainerStyle={{ backgroundColor: userButton }}
          selectedItemContainerStyle={{ backgroundColor: userButton }}
          style={{ backgroundColor: userButton }}
          placeholder="Select New Background"
          placeholderStyle={{ color: userText }}
          textStyle={{ color: userText }}
        />
      </View>

      <View style={styles.buttonContainer}>
        {/*  Save Background Button */}
        <TouchableOpacity
          onPress={handleDropdownChange}
          style={[
            styles.button,
            { backgroundColor: userButton, color: userText },
          ]}
        >
          <Text
            style={[
              styles.buttonText,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Save Background
          </Text>
        </TouchableOpacity>

        {/*  Create Custom Background Button */}
        <TouchableOpacity
          onPress={() => navigation.navigate("CreateBackgroundScreen")}
          style={[
            styles.button,
            { backgroundColor: userButton, color: userText },
          ]}
        >
          <Text
            style={[
              styles.buttonText,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Create Custom background{" "}
          </Text>
        </TouchableOpacity>

        {/*  Tutorial Button */}
        <TouchableOpacity
          onPress={handleYoutube}
          style={[
            styles.button,
            { backgroundColor: userButton, color: userText },
          ]}
        >
          <Text
            style={[
              styles.buttonText,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Watch Tutorial
          </Text>
        </TouchableOpacity>

        {/*  Reminders Button */}
        <TouchableOpacity
          onPress={() => navigation.navigate("RemindersScreen")} // go to reminders screen
          style={[
            styles.button,
            { backgroundColor: userButton, color: userText },
          ]}
        >
          <Text
            style={[
              styles.buttonText,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Set Reminders{" "}
          </Text>
        </TouchableOpacity>

        <View
          style={{
            opacity: Platform.OS === "android" ? 0 : 10,
            pointerEvents: Platform.OS === "android" ? "none" : "auto",
          }}
        >
          <TouchableOpacity
            onPress={() => navigation.navigate("Home")}
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}> Return to Home Screen </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
  },

  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  container: {
    marginTop: 50,
    padding: 50,
    justifyContent: "center",
    alignItems: "center",
  },

  title: {
    backgroundColor: "#FFA500",
    width: 150,
    textAlign: "center",
    marginTop: 0,
    fontSize: 24,
    fontWeight: "bold",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  pickerContainer: {
    width: "60%",
    alignSelf: "center",
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginTop: 60,
    zIndex: 999,
  },

  buttonContainer: {
    width: "60%",
    flex: 1,
    marginTop: "10%",
    justifyContent: "center",
    alignSelf: "center",
    paddingHorizontal: 10,
    marginHorizontal: 75,
  },

  backButton: {
    width: "100%",
    borderRadius: 10,
    alignItems: "center",
    marginTop: "40%",
  },

  backButtonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },

  button: {
    backgroundColor: "#FFA500",
    width: "100%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
    marginBottom: "15%",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
  },

  buttonText: {
    color: "black",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
  },
});

export default SettingsScreen;
