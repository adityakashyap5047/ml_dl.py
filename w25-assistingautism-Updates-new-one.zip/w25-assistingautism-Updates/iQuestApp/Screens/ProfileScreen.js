import React, { useEffect, } from "react";
import {
  auth,
} from "../firebase";
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Image,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard,
} from "react-native";
import editIcon from "../assets/edit.png";
import { useIsFocused } from "@react-navigation/native";
import { useTheme } from "../src/ThemeContext";
import { themeStyles, generateStylesForColor } from "../src/styles";
import { useUserPreferences } from "../src/UserPreferencesContext";
import { useProfileContext } from "../src/ProfileContext";
import defaultProfilePicture from "../Images/pp.png";

const ProfileScreen = ({ navigation }) => {
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const isURLImage =
    typeof backgroundImage === "string" && backgroundImage.startsWith("http");

  const { userBackground, userButton, userText, fetchColors } = useUserPreferences();
  const { profileData, fetchData } = useProfileContext();  // Use the hook to get profileData and fetchData

  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      fetchColors(auth.currentUser.uid);
      fetchData();
    }
  }, [isFocused]);

  return (
    <View style={[bgStyles.container, { backgroundColor: userBackground }]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />

      <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
        <KeyboardAvoidingView
          style={styles.topContainer}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 0 : -50}
        >
          <View style={styles.header}>
            <TouchableOpacity
              onPress={() => navigation.navigate("EditProfileScreen")}
            >
              <View
                style={[
                  styles.editIconContainer,
                  { backgroundColor: userButton },
                ]}
              >
                <Image source={editIcon} style={styles.editIcon}></Image>
              </View>
            </TouchableOpacity>
          </View>

          <Text
            style={[
              styles.title,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Profile
          </Text>

          <View>
            {profileData.profilePicture ? (
              <Image source={{ uri: profileData.profilePicture }} style={styles.profileImage} />
            ) : (
              <Image source={defaultProfilePicture} style={styles.profileImage} />
            )}
          </View>

          <Text style={{ fontSize: 16, color: userText, fontWeight: "bold" }}>
            {profileData.first} {profileData.last}
          </Text>
          <Text style={{ fontSize: 16, color: userText, fontWeight: "500" }}>
            {profileData.email}
          </Text>
          <Text style={{ fontSize: 16, color: userText, fontWeight: "500" }}>
            {profileData.born}
          </Text>
          <Text
            style={{
              fontSize: 16,
              color: userText,
              fontWeight: "500",
              marginBottom: 10,
            }}
          >
            {profileData.grade}
          </Text>
          <Text
            style={[
              styles.label,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Things and Activities I Like
          </Text>

          <Text style={[styles.inputBox, { color: userText }]}>
            {profileData.likes || ''}
          </Text>

          <Text
            style={[
              styles.label,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Hopes and Dreams for My Future
          </Text>

          <Text style={[styles.inputBox, { color: userText }]}>
            {profileData.dreams || ''}
          </Text>


          <View style={styles.labelContainer}>
            <TouchableOpacity
              onPress={() => navigation.navigate("CompletedGoalsScreen")}
              style={[styles.completedButton, { backgroundColor: userButton }]}
            >
              <Text style={[styles.buttonText, { color: userText }]}>
                View Your Completed Goals
              </Text>
            </TouchableOpacity>
          </View>

          <View
            style={{
              opacity: Platform.OS === "android" ? 0 : 10,
              pointerEvents: Platform.OS === "android" ? "none" : "auto",
            }}
          >
            <TouchableOpacity
              onPress={() => navigation.navigate("Home")}
              style={styles.backButton}
            >
              <Text style={styles.backButtonText}> Return to Home Screen </Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
    </View>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  topContainer: {
    marginTop: "5%",
    justifyContent: "center",
    alignItems: "center",
  },

  bottomContainer: {
    flex: 1,
    justifyContent: "center",
  },

  title: {
    backgroundColor: "#FFA500",
    width: 150,
    textAlign: "center",
    marginTop: 0,
    fontSize: 24,
    fontWeight: "bold",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  label: {
    backgroundColor: "#FFA500",
    width: 250,
    textAlign: "center",
    marginTop: 0,
    fontSize: 14,
    fontWeight: "bold",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  profileImage: {
    backgroundColor: "#FFA500",
    marginTop: 20,
    width: 150,
    height: 150,
    borderRadius: 75,
    marginVertical: 10,
  },

  inputName: {
    width: "80%",
    marginVertical: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    backgroundColor: "white",
    borderColor: "black",
    textAlign: "center",
  },

  Wrapper: {
    flexDirection: "row",
    alignItems: "center",
    width: "80%",
    justifyContent: "space-between",
  },

  inputWrapper: {
    width: "45%",
    marginVertical: 10,
    padding: 10,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "white",
    borderColor: "black",
    textAlign: "center",
  },

  inputBox: {
    width: "90%",
    height: "15%",
    marginVertical: 10,
    padding: 10,
    borderWidth: 1.5,
    overflow: "hidden",
    borderRadius: 5,
    backgroundColor: "rgba(255, 255, 255, 0.8)", // White with 80% opacity

    borderColor: "black",
  },

  header: {
    flexDirection: "row",
    justifyContent: "flex-start",
    alignItems: "center",
    padding: 20,
  },

  editIconContainer: {
    position: "absolute",
    marginTop: "0%",
    right: "5%",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  backButtonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },

  button: {
    width: "100%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
  },

  editIcon: {
    height: 40,
    width: 40,
  },

  labelContainer: {
    height: "10%",
    marginTop: "5%",
    paddingBottom: 0,
    alignItems: "center",
  },

  completedButton: {
    backgroundColor: "#FFA500",
    width: "80%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    top: "10%",
    textAlign: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  buttonText: {
    color: "black",
    fontWeight: "bold",
    fontSize: 16,
    textAlign: "center",
  },
});

export default ProfileScreen;
