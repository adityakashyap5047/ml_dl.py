import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import React, { useState, useEffect } from "react";
import {
  ServerContainer,
  useIsFocused,
  useRoute,
} from "@react-navigation/native";
import {
  auth,
  db,
  getDocs,
  collection,
  query,
  where,
  addDoc,
  serverTimestamp,
  doc,
  updateDoc,
  setDoc,
  getDoc,
} from "../firebase";
import {
  StyleSheet,
  Text,
  SafeAreaView,
  ScrollView,
  StatusBar,
  Image,
  TouchableOpacity,
  View,
  Alert,
} from "react-native";
import { useUserPreferences } from "../src/UserPreferencesContext";

const GoalsScreen = ({ navigation }) => {
  //gets background
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const isURLImage =
    typeof backgroundImage === "string" && backgroundImage.startsWith("http");

  const { userBackground, userButton, userText, fetchColors } =
    useUserPreferences();
  const [home, setHome] = useState(0);
  const [school, setSchool] = useState(0);

  // gets section and category from goal screen
  const route = useRoute();
  const category = route.params.category;
  const section = route.params.section;

  //get current user id
  const uid = auth.currentUser.uid;

  //reload data every time you navigate to this page
  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      fetchUserGoals();
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]);

  // array to store all the goals
  const [goalChecklist, setGoalChecklist] = useState([]);
  const [defaultGoals, setDefaultGoals] = useState([]);

  //database queries
  const fetchUserGoals = async () => {
    console.log("fetching...");

    const defaultGoals = [];
    const q = query(
      collection(db, "defaultGoals"),
      where("category", "==", category),
      where("section", "==", section)
    );
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      defaultGoals.push(doc.data().description);
    });
    setDefaultGoals(defaultGoals);
    const docRef3 = doc(db, "users", uid);
    const docSnap = await getDoc(docRef3);

    if (docSnap.exists()) {
      console.log("Document data:", docSnap.data());
      setHome(docSnap.data().home);
      setSchool(docSnap.data().school);
    } else {
      // docSnap.data() will be undefined in this case
      console.log("No such document!");
    }
  };
  const handleAddGoal = async (description) =>
    Alert.alert("Do you want to add this goal?", description, [
      {
        text: "Cancel",
        onPress: () => console.log("Cancel Pressed"),
        style: "cancel",
      },
      {
        text: "Add",
        onPress: () => {
          console.log("Yes Pressed");
          AddGoal(description);
        },
      },
    ]);

  const AddGoal = async (description) => {
    if (section == "Home") {
      if (home < 2) {
        // Add a new document with a generated id.
        const docRef = await addDoc(collection(db, "goals"), {
          category: category,
          section: section,
          description: description,
          completed: false,
          createdAt: serverTimestamp(), // Add the serverTimestamp here
          dateOfCompletion: null, // or a
        });
        console.log("Document written with ID: ", docRef.id);
        const docRef2 = await addDoc(collection(db, "userGoals"), {
          goalID: docRef.id,
          userID: uid,
        });
        console.log("Document written with ID: ", docRef2.id);
        const updateRef = doc(db, "users", uid);

        // Set the "capital" field of the city 'DC'
        await updateDoc(updateRef, {
          home: home + 1,
        });
        alert("Goal Added");
        navigation.navigate("CategoriesScreen");
      } else {
        alert("You have too many Home Goals already, complete some!");
      }
    } else {
      if (school < 2) {
        // Add a new document with a generated id.
        const docRef = await addDoc(collection(db, "goals"), {
          category: category,
          section: section,
          description: description,
          completed: false,
          createdAt: serverTimestamp(),
          dateOfCompletion: null,
        });
        console.log("Document written with ID: ", docRef.id);
        const docRef2 = await addDoc(collection(db, "userGoals"), {
          goalID: docRef.id,
          userID: uid,
        });
        console.log("Document written with ID: ", docRef2.id);
        const updateRef = doc(db, "users", uid);

        // Set the "capital" field of the city 'DC'
        await updateDoc(updateRef, {
          school: school + 1,
        });
        alert("goal added");
        navigation.navigate("CategoriesScreen");
      } else {
        alert("You have too many School Goals already, Complete Some!");
      }
    }
  };

  return (
    <View style={[bgStyles.container, { backgroundColor: userBackground }]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />
      <SafeAreaView style={styles.container}>
        <Text
          style={[
            styles.text,
            { backgroundColor: userButton, color: userText },
          ]}
        >
          {section} {category} Goals
        </Text>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            onPress={() =>
              navigation.navigate("AddGoalScreen", {
                section: section,
                category: category,
              })
            }
          >
            <Text style={styles.buttonText}> Create Custom Goal</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          style={[styles.scrollView, { backgroundColor: userButton }]}
        >
          {defaultGoals.map((goal, index) => (
            <TouchableOpacity
              onPress={() => handleAddGoal(goal)}
              style={styles.button}
              key={index}
            >
              <View style={styles.checkboxContainer}>
                <Text style={[styles.checkboxText, { color: userText }]}>
                  {goal}
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View
          style={{
            opacity: Platform.OS === "android" ? 0 : 10,
            pointerEvents: Platform.OS === "android" ? "none" : "auto",
          }}
        >
          <TouchableOpacity
            onPress={() => navigation.navigate("CategoriesScreen")}
          >
            <Text style={styles.buttonText}> Return to Home Screen </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
  },

  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
  },

  buttonContainer: {
    marginTop: "5%",
  },

  scrollView: {
    //flex: 1,
    backgroundColor: "#FFA500",
    marginHorizontal: "3%",
    marginTop: "5%",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    marginBottom: 20,
  },

  text: {
    backgroundColor: "#FFA500",
    fontSize: 32,
    paddingHorizontal: 20,
    marginTop: "5%",
    alignSelf: "center",
    textAlign: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  checkboxText: {
    flex: 1,
    flexWrap: "wrap",
    paddingVertical: "2%",
  },

  button: {
    height: "8%",
    width: "100%",
    borderRadius: 10,
    alignItems: "center",
    paddingVertical: "2%",
  },

  buttonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },

  checkboxContainer: {
    flexShrink: 1,
    marginTop: "5%",
    //alignContent: "center",
    paddingHorizontal: 10,
    paddingVertical: "2%",
    justifyContent: "center",
  },
});

export default GoalsScreen;
