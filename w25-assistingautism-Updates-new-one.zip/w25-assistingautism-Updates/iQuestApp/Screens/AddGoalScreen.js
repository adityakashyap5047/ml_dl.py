import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import React, { useState, useEffect } from "react";
import { useIsFocused, useRoute } from "@react-navigation/native";
import {
  auth,
  db,
  getDocs,
  collection,
  query,
  where,
  serverTimestamp,
  addDoc,
  getDoc,
  setDoc,
  updateDoc,
  doc,
} from "../firebase";
import {
  StyleSheet,
  Text,
  SafeAreaView,
  StatusBar,
  Image,
  TouchableOpacity,
  View,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
  Alert,
} from "react-native";
import { useUserPreferences } from "../src/UserPreferencesContext";

const AddGoalScreen = ({ navigation }) => {
  //gets background
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const isURLImage =
    typeof backgroundImage === "string" && backgroundImage.startsWith("http");

  const [description, setDescription] = useState("");
  const [home, setHome] = useState(0);
  const [school, setSchool] = useState(0);
  const { userBackground, userButton, userText, fetchColors } =
    useUserPreferences();

  // gets section and category from goal screen
  const route = useRoute();
  const category = route.params.category;
  const section = route.params.section;

  //get current user id
  const uid = auth.currentUser.uid;

  //reload data every time you navigate to this page
  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      fetchDefaultGoals();
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]);

  // array to store all the goals
  const [defaultGoals, setDefaultGoals] = useState([]);

  //database queries
  const fetchDefaultGoals = async () => {
    console.log("fetching...");

    //get the description of the user goals from the correct category
    const defaultGoals = [];
    const q = query(
      collection(db, "defaultGoals"),
      where("category", "==", category),
      where("section", "==", section)
    );
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      defaultGoals.push({
        label: doc.data().description,
        value: doc.data().description,
      });
    });
    setDefaultGoals(defaultGoals);
    console.log(defaultGoals);
    const docRef3 = doc(db, "users", uid);
    const docSnap = await getDoc(docRef3);

    if (docSnap.exists()) {
      console.log("Document data:", docSnap.data());
      setHome(docSnap.data().home);
      setSchool(docSnap.data().school);
    } else {
      // docSnap.data() will be undefined in this case
      console.log("No such document!");
    }
  };

  const handleAddGoal = async () => {
    if (description != "") {
      if (section == "Home") {
        if (home < 2) {
          // Add a new document with a generated id.
          const docRef = await addDoc(collection(db, "goals"), {
            category: category,
            section: section,
            description: description,
            completed: false,
            createdAt: serverTimestamp(),
            dateOfCompletion: null,
          });
          console.log("Document written with ID: ", docRef.id);
          const docRef2 = await addDoc(collection(db, "userGoals"), {
            goalID: docRef.id,
            userID: uid,
          });
          console.log("Document written with ID: ", docRef2.id);
          const updateRef = doc(db, "users", uid);

          // Set the "capital" field of the city 'DC'
          await updateDoc(updateRef, {
            home: home + 1,
          });
          fetchDefaultGoals();

          Alert.alert("Custom Goal Added", "Would you want to add another Goal? ", [
            { text: "No",
              onPress: () => {
                navigation.navigate("Home");
              },
              style: "cancel",
            },
            { text: "Yes",
              onPress: () => {
                navigation.navigate("GoalsScreen", {
                  section: section,
                  category: category,
                });
              },
            },
          ]);

        } else {
          alert("You have too many Home Goals already, Complete Some!");
        }
      } else {
        if (school < 2) {
          // Add a new document with a generated id.
          const docRef = await addDoc(collection(db, "goals"), {
            category: category,
            section: section,
            description: description,
            completed: false,
            createdAt: serverTimestamp(),
            dateOfCompletion: null,
          });
          console.log("Document written with ID: ", docRef.id);
          const docRef2 = await addDoc(collection(db, "userGoals"), {
            goalID: docRef.id,
            userID: uid,
          });
          console.log("Document written with ID: ", docRef2.id);
          const updateRef = doc(db, "users", uid);

          // Set the "capital" field of the city 'DC'
          await updateDoc(updateRef, {
            school: school + 1,
          });
          Alert.alert("Custom Goal Added", "Would you want to add another Goal? ", [
            { text: "No",
              onPress: () => {
                navigation.navigate("Home");
              },
              style: "cancel",
            },
            { text: "Yes",
              onPress: () => {
                navigation.navigate("GoalsScreen", {
                  section: section,
                  category: category,
                });
              },
            },
          ]);
          fetchDefaultGoals();
        } else {
          alert("You have too many School Goals already, Complete Some!");
        }
      }
    } else {
      alert("Please Add a Custom Goal");
    }
  };

  return (
    <View style={[bgStyles.container, { backgroundColor: userBackground }]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />

      <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
        <SafeAreaView style={styles.container}>
          <Text
            style={[
              styles.text,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Add new goal for {section} {category}
          </Text>

          <View style={styles.container}>
            <View style={styles.row}>
              <Text
                style={[
                  styles.label,
                  { backgroundColor: userButton, color: userText },
                ]}
              >
                Create Your Own Goal:
              </Text>
              <TextInput
                style={styles.input}
                placeholder="Enter a Description"
                autoCapitalize="words"
                value={description}
                onChangeText={(text) => setDescription(text)}
              />
            </View>

            <View style={styles.buttonContainer}>
              <TouchableOpacity onPress={handleAddGoal}>
                <Text
                  style={[
                    styles.button,
                    { backgroundColor: userButton, color: userText },
                  ]}
                >
                  Add Custom Goal
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <View
            style={{
              opacity: Platform.OS === "android" ? 0 : 10,
              pointerEvents: Platform.OS === "android" ? "none" : "auto",
            }}
          >
            <TouchableOpacity
              onPress={() =>
                navigation.navigate("GoalsScreen", {
                  section: section,
                  category: category,
                })
              }
              style={styles.backButton}
            >
              <Text style={styles.backButtonText}> Return to Goal Screen </Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </TouchableWithoutFeedback>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
  },

  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
  },

  buttonContainer: {
    //flex: 1,
    marginTop: "50%",
  },

  text: {
    backgroundColor: "#FFA500",
    fontSize: 32,
    marginHorizontal: 5,
    textAlign: "center",
    marginTop: "5%",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  button: {
    backgroundColor: "#FFA500",
    fontSize: 32,
    marginHorizontal: 5,
    textAlign: "center",
    marginTop: "5%",
    width: "80%",
    alignSelf: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  buttonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
  },

  row: {
    //flexDirection: "row",
    alignItems: "center",
    //marginTop: "1%",
    zIndex: 999,
    height: "30%",
    //backgroundColor: "white",
  },

  title: {
    backgroundColor: "#FFA500",
    width: 150,
    textAlign: "center",
    //marginTop: 50,
    fontSize: 24,
    fontWeight: "bold",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  label: {
    backgroundColor: "#FFA500",
    textAlign: "center",
    fontSize: 20,
    fontWeight: "bold",
    paddingHorizontal: 20,
    marginTop: "20%",
    borderRadius: 5,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  input: {
    marginTop: "5%",
    borderWidth: 2,
    borderColor: "black",
    padding: 8,
    height: "100%",
    width: "95%",
    borderWidth: 1,
    borderRadius: 8,
    backgroundColor: "white",
    textAlign: "center",
  },

  backButton: {
    width: "100%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
  },

  backButtonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },
});

export default AddGoalScreen;
