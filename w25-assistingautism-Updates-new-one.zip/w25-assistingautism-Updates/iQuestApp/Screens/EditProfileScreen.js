import React, { useEffect, useState } from "react";
import DateTimePicker from '@react-native-community/datetimepicker';
import { useIsFocused } from "@react-navigation/native";
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    Image,
    TouchableOpacity,
    TouchableWithoutFeedback,
    Keyboard,
    ScrollView,
    KeyboardAvoidingView,
    Modal,
    FlatList,
    Platform,
} from "react-native";
import checkmark from "../assets/Checkmark-Green.png";
import xIcon from "../assets/x-red.png";
import defaultProfilePicture from "../Images/pp.png";
import {
    auth,
    db,
    doc,
    updateDoc,
    storage,
} from "../firebase";

import * as ImagePicker from "expo-image-picker";
import * as ImageManipulator from 'expo-image-manipulator';
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import DropDownPicker from "react-native-dropdown-picker";

import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import { useProfileContext } from "../src/ProfileContext";
import { useUserPreferences } from "../src/UserPreferencesContext";

const labelButtonColor = "#FFA500";

const EditProfileScreen = ({ navigation }) => {
    const { theme, backgroundImage } = useTheme();
    const bgStyles = themeStyles[theme];
    const isURLImage =
        typeof backgroundImage === "string" && backgroundImage.startsWith("http");
    const { profileData, fetchData } = useProfileContext();  // Use the hook to get profileData and fetchData
    const [userId, setUserId] = useState(auth.currentUser?.uid);  // Initialize with the UID
    const [first, setFirst] = useState(profileData.first);
    const [last, setLast] = useState(profileData.last);
    // const [email, setEmail] = useState("");
    const [born, setBorn] = useState(new Date()); // Initialize with current date
    const [showDatePicker, setShowDatePicker] = useState(Platform.OS === 'ios');
    const [grade, setGrade] = useState(profileData.grade);
    const [likes, setLikes] = useState(profileData.likes);
    const [dreams, setDreams] = useState(profileData.dreams);

    const [profilePicture, setProfilePicture] = useState(profileData.profilePicture); // Store the image URI here
    const [image, setImage] = useState(null);
    const [cameraPermission, setCameraPermission] = useState(null);
    const [galleryPermission, setGalleryPermission] = useState(null);

    const { userBackground, userButton, userText, fetchColors } = useUserPreferences();
    const [modalVisible, setModalVisible] = useState(false);

    const grades = [
        { label: "Kindergarten", value: "Kindergarten" },
        { label: "1st", value: "1st Grade" },
        { label: "2nd", value: "2nd Grade" },
        { label: "3rd", value: "3rd Grade" },
        { label: "4th", value: "4th Grade" },
        { label: "5th", value: "5th Grade" },
        { label: "6th", value: "6th Grade" },
        { label: "7th", value: "7th Grade" },
        { label: "8th", value: "8th Grade" },
        { label: "9th", value: "9th Grade" },
        { label: "10th", value: "10th Grade" },
        { label: "11th", value: "11th Grade" },
        { label: "12th", value: "12th Grade" },
        {
            label: "Post-Secondary School Program",
            value: "Post-Secondary School Program",
        },
        { label: "College/University", value: "College/University" },
        { label: "Not in School", value: "Not in School" },
        { label: "Other", value: "Other" },
    ];

    const formattedDate = born.toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
    });

    // reload page and queries
    const isFocused = useIsFocused();
    useEffect(() => {
        if (isFocused) {
            fetchData();
            fetchColors(auth.currentUser.uid);
            permissionFunction();
        }
    }, [isFocused]);

    const openDatePicker = () => {
        setShowDatePicker(true);
    };

    const onChange = (event, selectedDate) => {
        const currentDate = selectedDate || born;
        setShowDatePicker(Platform.OS === 'ios'); // On iOS, show the modal again after selecting a date
        setBorn(currentDate);
    };

    const permissionFunction = async () => {
        const imagePermission =
            await ImagePicker.requestMediaLibraryPermissionsAsync();
        console.log(`Image Permission: ${imagePermission.status}`);

        setGalleryPermission(imagePermission.status === "granted");
        if (imagePermission.status !== "granted") {
            alert("Permission for media access needed");
        }
    };

    const pickImage = async () => {
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [1, 1],
            quality: 1,
        });

        if (!result.canceled) {
            // Use the "assets" array to access selected assets
            const selectedAsset = result.assets[0];

            // Resize the image to a smaller size
            const resizedImage = await ImageManipulator.manipulateAsync(
                selectedAsset.uri,
                [{ resize: { width: 300, height: 300 } }],
                { compress: 0.2, format: ImageManipulator.SaveFormat.JPEG }
            );

            setProfilePicture(resizedImage.uri);
        }
    };

    const imageUpload = async () => {
        try {
            if (profilePicture) {
                // Convert the local image URI to a Blob
                const response = await fetch(profilePicture);
                const blob = await response.blob();

                // Define the path in Firebase Storage
                const storagePath = `profile_pictures/${first}_${last}_${userId}.jpg`;
                const storageRef = ref(storage, storagePath);

                // Upload the image to Firebase Storage
                await uploadBytes(storageRef, blob);

                // Get the download URL of the uploaded image
                const downloadURL = await getDownloadURL(storageRef);

                console.log("Image uploaded successfully!");
                return downloadURL;
            } else {
                console.log("No image selected");
                return null;
            }
        } catch (error) {
            console.error("Error uploading image:", error);
            return null;
        }
    };

    const handleUpdateProfile = async () => {
        try {
            // Upload image to Firebase Storage and get download URL
            const downloadURL = await imageUpload();

            //console.log("Download URL:", downloadURL);

            const userRef = doc(db, "users", userId);

            // Check if downloadURL is available before updating the profile
            await updateDoc(userRef, {
                first: first,
                last: last,
                grade: grade,
                born: born,
                // Update profilePicture with the download URL
                profilePicture: downloadURL,
                likes: likes !== undefined ? likes : null,
                dreams: dreams !== undefined ? dreams : null,
            });
        } catch (error) {
            console.error("Error updating data: ", error);
        }
        navigation.navigate("ProfileScreen");
    };

    const renderItem = ({ item }) => (
        <TouchableOpacity
            style={{ padding: 16, borderBottomWidth: 1, borderBottomColor: userText }}
            onPress={() => {
                setGrade(item.value); // Set the selected grade to the state
                setModalVisible(false);
            }}
        >
            <Text style={{ color: userText }} >{item.label}</Text>
        </TouchableOpacity>
    );


    return (
        <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
            <KeyboardAvoidingView
                style={[bgStyles.container, { backgroundColor: userBackground }]}
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            >
                <Image
                    source={
                        { uri: backgroundImage }
                    }
                    style={styles.backgroundImage}
                />

                {/* Edit Profile Title */}
                <View style={styles.titleContainer}>
                    <Text style={[styles.title, { backgroundColor: userButton, color: userText }]}>
                        Edit Profile
                    </Text>
                </View>


                <ScrollView
                    style={[styles.scrollView, { borderColor: userButton }]}
                    contentContainerStyle={{ flexGrow: 1, paddingBottom: 200 }}
                >

                    <View style={styles.container}>

                        {/* Clickable Profile Picture */}
                        <TouchableOpacity onPress={pickImage}>
                            {profilePicture ? (
                                <Image
                                    source={{ uri: profilePicture }}
                                    style={styles.profileImage}
                                />
                            ) : (
                                <Image
                                    source={defaultProfilePicture}
                                    style={styles.profileImage}
                                />
                            )}
                        </TouchableOpacity>

                        {/* First Name*/}
                        <View style={styles.row}>
                            <Text style={[styles.label, { backgroundColor: userButton, color: userText }]}>
                                First Name:
                            </Text>
                            <TextInput
                                style={styles.input}
                                placeholder="Enter your first name"
                                autoCapitalize="words"
                                value={first}
                                onChangeText={(text) => setFirst(text)}
                            />
                        </View>

                        {/* Last Name*/}
                        <View style={styles.row}>
                            <Text style={[styles.label, { backgroundColor: userButton, color: userText }]}>
                                Last Name:
                            </Text>
                            <TextInput
                                style={styles.input}
                                placeholder="Enter your last name"
                                autoCapitalize="words"
                                value={last}
                                onChangeText={(text) => setLast(text)}
                            />
                        </View>

                        {/* Birthday */}
                        <View style={styles.row}>
                            <Text style={[styles.label, { backgroundColor: userButton, color: userText }]}>
                                Birthday
                            </Text>
                            {Platform.OS === 'android' && (
                                <TouchableOpacity onPress={openDatePicker} style={styles.dateContainer}>
                                    <Text style={styles.datePicker}>{formattedDate}</Text>
                                </TouchableOpacity>
                            )}
                            {showDatePicker && (
                                <DateTimePicker
                                    value={born}
                                    mode="date"
                                    display="default"
                                    onChange={onChange}
                                    style={styles.datePicker}
                                />
                            )}
                        </View>

                        {/* Grade Selector */}
                        <View style={styles.row}>
                            <Text style={[styles.label, { backgroundColor: userButton, color: userText }]}>
                                Grade
                            </Text>

                            {/* Modal Trigger */}
                            <TouchableOpacity onPress={() => setModalVisible(true)} style={styles.input}>
                                <Text style={{ textAlign: "center" }}>{grade}</Text>
                            </TouchableOpacity>

                            {/* Modal */}
                            <Modal
                                animationType="slide"
                                transparent={false}
                                visible={modalVisible}
                                onRequestClose={() => setModalVisible(false)}

                            >
                                <View style={[styles.modal, { backgroundColor: userButton }]}>
                                    <FlatList style={{ marginTop: "10%" }}
                                        data={grades}
                                        renderItem={renderItem}
                                        keyExtractor={(item) => item.value}
                                    />
                                    <TouchableOpacity style={{ marginTop: "5%", marginBottom: "5%", color: userText }}
                                        onPress={() => setModalVisible(false)}>
                                        <Text style={{ color: userText }}> Close </Text>
                                    </TouchableOpacity>
                                </View>
                            </Modal>
                        </View>

                        {/* Hobbies */}
                        <Text style={[styles.labelLong, { backgroundColor: userButton, color: userText }]}>
                            Things and Activities I Like
                        </Text>
                        <TextInput
                            style={styles.inputBox}
                            placeholder="Enter Things and Activities Here:"
                            value={likes}
                            onChangeText={(text) => { setLikes(text); }}
                            multiline={true}
                        />

                        {/* Dreams */}
                        <Text style={[styles.labelLong, { backgroundColor: userButton, color: userText }]}>
                            Hopes and Dreams for My Future
                        </Text>
                        <TextInput
                            style={styles.inputBox}
                            placeholder="Enter Hopes and Dreams Here:"
                            value={dreams}
                            onChangeText={(text) => { setDreams(text); }}
                            multiline={true}
                        />


                    </View>

                </ScrollView>

                {/* Icons */}
                <View style={styles.footer}>
                    <TouchableOpacity onPress={() => navigation.navigate("ProfileScreen")}>
                        <View style={styles.leftIconContainer}>
                            <Image source={xIcon} style={styles.icon}></Image>
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={handleUpdateProfile}>
                        <View style={styles.rightIconContainer}>
                            <Image source={checkmark} style={styles.icon}></Image>
                        </View>
                    </TouchableOpacity>
                </View>
            </KeyboardAvoidingView>
        </TouchableWithoutFeedback>
    );
};

const styles = StyleSheet.create({

    titleContainer: {
        marginTop: "5%",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: "5%",
    },

    scrollView: {
        marginHorizontal: 10,
        marginTop: 20,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: labelButtonColor,
        marginBottom: "5%"
    },

    container: {
        padding: 10,
        justifyContent: "center",
        alignItems: "center",
        paddingBottom: 20,
    },

    pickerContainer: {
        width: "65%",
        alignItems: "center",
    },

    backgroundImage: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        resizeMode: "stretch",
    },

    title: {
        width: "50%",
        textAlign: "center",
        marginTop: "10%",
        fontSize: 24,
        fontWeight: "bold",
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "black",
        overflow: "hidden",
    },

    profileImage: {
        marginTop: Platform.isPad? "8%" : "20%",
        width: 150,
        height: 150,
        borderRadius: 75,
        marginVertical: 10,
    },

    row: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 16,
        zIndex: 999,
    },

    label: {
        flex: 1,
        textAlign: "center",
        fontSize: 20,
        fontWeight: "bold",
        marginRight: 8,
        marginLeft: 8,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: "black",
        overflow: "hidden",
    },

    labelLong: {
        width: 300,
        textAlign: "center",
        marginTop: 0,
        fontSize: 18,
        fontWeight: "bold",
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "black",
        overflow: "hidden",
    },

    input: {
        flex: 2,
        borderWidth: 2,
        borderColor: "black",
        padding: 3,
        borderWidth: 1,
        borderRadius: 8,
        backgroundColor: "white",
        textAlign: "center",
        fontSize: 18,
    },

    inputBox: {
        width: "100%",
        height: "20%",
        marginVertical: 10,
        padding: 10,
        borderWidth: 1,
        borderRadius: 5,
        backgroundColor: "white",
        borderColor: "black",
    },

    datePickerLabel: {
        fontSize: 20,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: "black",
        overflow: "hidden",
        fontWeight: "bold",
    },

    datePickerContainer: {
        flexDirection: "row",
        alignItems: "center",
        zIndex: 999,
    },

    datePicker: {
        backgroundColor: "white",
        fontSize: 18, // Adjust the font size as needed
        color: "black", // Adjust the text color as needed
        textAlign: "center", // Center the text horizontally
        alignItems: "center",
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "black",
        overflow: "hidden",
    },

    footer: {
        flexDirection: "row",
        justifyContent: "center",
        //flex: 1, // Add flex: 1
        height: "15%",

    },

    modal: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 20,
    },  

    leftIconContainer: {
        right: "125%",
    },

    rightIconContainer: {
        left: "150%",
    },

    icon: {
        height: 60,
        width: 60,
    },
});

export default EditProfileScreen;
