import React, { useState, useEffect, useRef } from "react";
import {
  StyleSheet,
  Text,
  StatusBar,
  Image,
  TouchableOpacity,
  View,
  Platform,
} from "react-native";
import { auth, db, getDoc, doc } from "../firebase";
import { useIsFocused } from "@react-navigation/native"
import * as Device from "expo-device";
import * as Notifications from "expo-notifications";
import { Picker } from "@react-native-picker/picker";
import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import { useUserPreferences } from "../src/UserPreferencesContext";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

const RemindersScreen = ({ navigation }) => {
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const isURLImage =
    typeof backgroundImage === "string" && backgroundImage.startsWith("http");
  const [category, setCategory] = useState(""); // State for the category selection
  const { userBackground, userButton, userText, fetchColors } = useUserPreferences();

  const [expoPushToken, setExpoPushToken] = useState("");
  const [notification, setNotification] = useState(false);
  const notificationListener = useRef();
  const responseListener = useRef();

  useEffect(() => {
    registerForPushNotificationsAsync().then((token) =>
      setExpoPushToken(token)
    );

    notificationListener.current =
      Notifications.addNotificationReceivedListener((notification) => {
        setNotification(notification);
      });

    responseListener.current =
      Notifications.addNotificationResponseReceivedListener((response) => {
        console.log(response);
      });

    return () => {
      Notifications.removeNotificationSubscription(
        notificationListener.current
      );
      Notifications.removeNotificationSubscription(responseListener.current);
    };
  }, []);


  // reload page and queries
  const isFocused = useIsFocused();
  useEffect(() => {
    // Fetch data when the screen is focused or on component mount
    if (isFocused) {
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]); // Run when isFocused changes

  return (
    <View style={[bgStyles.container, { backgroundColor: userBackground }]}>
      <Image
        source={{ uri: backgroundImage }}
        style={styles.backgroundImage}
      />

      <View style={styles.container}>
        <Text style={[styles.title, { backgroundColor: userButton, color: userText }]}>Set Reminders</Text>

        {/* Dropdown for selecting a category */}

        <View style={[styles.pickerContainer, { backgroundColor: userButton}]}>
          <Picker
            selectedValue={category}
            onValueChange={(itemValue) => setCategory(itemValue)}
            style={styles.picker}
            itemStyle={{color: userText}}
          >
            <Picker.Item label="Reminder Frequency:" value="0"/>
            <Picker.Item label="Once a Day" value="1"/>
            <Picker.Item label="Twice a Day" value="2"/>
            <Picker.Item label="Three Times a Day" value="3"/>
            <Picker.Item label="Never" value="4"/>
          </Picker>
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            onPress={async () => {
              await schedulePushNotification();
            }}
            style={[styles.button, { backgroundColor: userButton, color: userText }]}
          >
            <Text style={[styles.buttonText, {color: userText }]}>
              {" "}
              Press to Send Test Notification{" "}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={{opacity: Platform.OS === 'android' ? 0 : 10, pointerEvents: Platform.OS === 'android' ? 'none' : "auto"}}>
          <TouchableOpacity
            onPress={() => navigation.navigate("SettingsScreen")}
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}> Return to Settings Screen </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

async function schedulePushNotification() {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: "You've got mail! 📬",
      body: "Here is your Test Notification",
      data: { data: "goes here" },
    },
    trigger: { seconds: 2 },
  });
}

async function registerForPushNotificationsAsync() {
  let token;

  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("default", {
      name: "default",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#FF231F7C",
    });
  }

  if (Device.isDevice) {
    const { status: existingStatus } =
      await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== "granted") {
      alert("Failed to get push token for push notification!");
      return;
    }
    token = (await Notifications.getExpoPushTokenAsync()).data;
    console.log(token);
  } else {
    alert("Must use physical device for Push Notifications");
  }

  return token;
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover", // You can change this to "contain" or other values based on your image requirements
  },
  
  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
  },

  pickerContainer: {
    marginTop: "10%",
    alignSelf: "center",
    justifyContent: "center",
    backgroundColor: "#FFA500",
    width: "75%",
    height: Platform.OS === 'android' ? "10%" : 230,
    marginHorizontal: 20,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },


  title: {
    backgroundColor: "#FFA500",
    width: "40%",
    textAlign: "center",
    alignSelf: "center",
    marginTop: "20%",
    marginHorizontal: 120,
    fontSize: 24,
    fontWeight: "bold",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  picker: {
    width: "100%",
  },

  text: {
    backgroundColor: "#FFA500",
    fontSize: 20,
    marginHorizontal: 5,
    marginTop: 10,
    textDecorationLine: "underline",
  },

  backButton: {
    //backgroundColor: "#FFA500",
    width: "100%",
    padding: 10,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
    marginBottom: 30,
  },

  backButtonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },

  buttonContainer: {
    //backgroundColor: "white",
    width: "90%",
    flex: 1,
    justifyContent: "center",
    alignSelf: "center",
    paddingHorizontal: 10,
  },

  button: {
    backgroundColor: "#FFA500",
    width: "100%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    marginBottom: 50,
    borderWidth: 1,
    borderColor: "black",
  },

  buttonText: {
    color: "black",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
  },
});
export default RemindersScreen;
