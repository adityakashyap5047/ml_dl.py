import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import React, { useState, useEffect } from "react";
import {
  ServerContainer,
  useIsFocused,
  useRoute,
} from "@react-navigation/native";
import { auth, db, getDocs, collection, query, where } from "../firebase";
import {
  StyleSheet,
  Text,
  SafeAreaView,
  ScrollView,
  StatusBar,
  Image,
  TouchableOpacity,
  View,
} from "react-native";
import { useUserPreferences } from "../src/UserPreferencesContext";

const MyGoalsScreen = ({ navigation }) => {
  //gets background
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const isURLImage =
    typeof backgroundImage === "string" && backgroundImage.startsWith("http");

  const { userBackground, userButton, userText, fetchColors } =
    useUserPreferences();

  //get current user id
  const uid = auth.currentUser.uid;

  //reload data everytime you navigate to this page
  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      fetchUserGoals();
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]);

  // array to store all the goals
  const [homeGoalList, setHomeGoalList] = useState([]);
  const [schoolGoalList, setSchoolGoalList] = useState([]);

  //database queries
  const fetchUserGoals = async () => {
    console.log("fetching...");

    // gets the goals that are linked to the current user
    const goalIds = [];
    const q = query(collection(db, "userGoals"), where("userID", "==", uid));
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      goalIds.push({
        id: doc.data().goalID,
      });
    });

    //get the description of the user goals from the correct category
    const homeGoalDescriptions = [];
    const schoolGoalDescriptions = [];
    const q2 = query(collection(db, "goals"), where("completed", "==", false));
    const querySnapshot2 = await getDocs(q2);
    querySnapshot2.forEach((doc) => {
      if (goalIds.some((goal) => goal.id === doc.id)) {
        if (doc.data().section == "Home") {
          homeGoalDescriptions.push({
            id: doc.id,
            description: doc.data().description,
            section: doc.data().section,
            category: doc.data().category,
          });
        } else {
          schoolGoalDescriptions.push({
            id: doc.id,
            description: doc.data().description,
            section: doc.data().section,
            category: doc.data().category,
          });
        }
      }
    });
    setHomeGoalList(homeGoalDescriptions);
    setSchoolGoalList(schoolGoalDescriptions);
  };

  return (
    <View style={[bgStyles.container, { backgroundColor: userBackground }]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />
      <SafeAreaView style={styles.container}>
        <Text
          style={[
            styles.title,
            { backgroundColor: userButton, color: userText },
          ]}
        >
          My Current Goals
        </Text>

        <Text
          style={[
            styles.label,
            { backgroundColor: userButton, color: userText },
          ]}
        >
          Home Goals
        </Text>

        {/* Display Current Home Goals */}
        <ScrollView
          style={[styles.scrollView, { backgroundColor: userButton }]}
        >
          {homeGoalList.map((goal, index) => (
            <TouchableOpacity
              onPress={() =>
                navigation.navigate("GoalProgressScreen", {
                  goalId: goal.id,
                  section: goal.section,
                })
              }
              style={styles.button}
              key={index}
            >
              <View style={styles.checkboxContainer}>
                <Text style={[styles.checkboxText, { color: userText }]}>
                  {goal.description}
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <Text
          style={[
            styles.label,
            { backgroundColor: userButton, color: userText, marginTop: "2%" },
          ]}
        >
          School Goals
        </Text>

        {/* Display Current School Goals */}
        <ScrollView
          style={[styles.scrollView, { backgroundColor: userButton }]}
        >
          {schoolGoalList.map((goal, index) => (
            <TouchableOpacity
              onPress={() =>
                navigation.navigate("GoalProgressScreen", {
                  goalId: goal.id,
                  section: goal.section,
                })
              }
              style={styles.button}
              key={index}
            >
              <View style={styles.checkboxContainer}>
                <Text style={[styles.checkboxText, { color: userText }]}>
                  {goal.description}
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View
          style={{
            opacity: Platform.OS === "android" ? 0 : 10,
            pointerEvents: Platform.OS === "android" ? "none" : "auto",
          }}
        >
          <TouchableOpacity onPress={() => navigation.navigate("Home")}>
            <Text style={styles.buttonText}> Return to Home Screen </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
  },

  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
  },

  buttonContainer: {
    marginTop: "5%",
  },

  scrollView: {
    flex: 1,
    //height: "10%",
    backgroundColor: "#FFA500",
    marginHorizontal: "3%",
    marginTop: "2%",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    marginBottom: 10,
  },

  title: {
    backgroundColor: "#FFA500",
    fontSize: 32,
    paddingHorizontal: 20,
    marginTop: "5%",
    alignSelf: "center",
    textAlign: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  label: {
    backgroundColor: "#FFA500",
    fontSize: 16,
    width: "50%",
    paddingHorizontal: 20,
    marginTop: "5%",
    alignSelf: "center",
    textAlign: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  checkboxText: {
    flex: 1,
    flexWrap: "wrap",
    marginTop: "5%",
    paddingVertical: "20%",
  },

  button: {
    height: "10%",
    width: "100%",
    borderRadius: 10,
    alignItems: "center",
    paddingVertical: "2%",
  },

  buttonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },

  checkboxContainer: {
    flexShrink: 1,
    justifyContent: "center",
    paddingHorizontal: 10,
    paddingVertical: "2%",
    //marginTop: "5%"
  },
});

export default MyGoalsScreen;
