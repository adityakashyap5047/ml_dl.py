import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  Button,
} from "react-native";
import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import * as ImagePicker from "expo-image-picker";
import * as ImageManipulator from 'expo-image-manipulator';
import { TriangleColorPicker, toHsv } from "react-native-color-picker"; // https://github.com/instea/react-native-color-picker
import ColorPicker from "react-native-wheel-color-picker"; // https://github.com/Naeemur/react-native-wheel-color-picker
import { auth, db, getDoc, doc, updateDoc, storage } from "../firebase";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { useIsFocused } from "@react-navigation/native";
import { useUserPreferences } from "../src/UserPreferencesContext";

const CreateBackgroundScreen = ({ navigation }) => {
  const { theme, changeTheme, changeBackgroundImage, backgroundImage } =
    useTheme();
  const bgStyles = themeStyles[theme];
  const { userBackground, userButton, userText, fetchColors } = useUserPreferences();

  const [customBackground, setCustomBackground] = useState("");

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync();
  
    if (!result.canceled) {
      const selectedAsset = result.assets[0];
      setCustomBackground(selectedAsset.uri);
      changeBackgroundImage(selectedAsset.uri); // Trigger background update
  
      // Update the firestore doc with the custom image uri
      if (selectedAsset.uri) {
        const downloadURL = await imageUpload(selectedAsset.uri);
        const userRef = doc(db, "users", auth.currentUser.uid);

        console.log(downloadURL);
  
        await updateDoc(userRef, {
          backgroundChoice: "Custom",
          customBackground: downloadURL,
        });
      }
    }
  };

  const imageUpload = async (uri) => {
    try {
      // Convert the local image URI to a Blob
      const response = await fetch(uri);
      const blob = await response.blob();
  
      // Define the path in Firebase Storage
      const storagePath = `user_backgrounds/${auth.currentUser.uid}.jpg`;
      const storageRef = ref(storage, storagePath);
  
      // Upload the image to Firebase Storage
      await uploadBytes(storageRef, blob);
  
      // Get the download URL of the uploaded image
      const downloadURL = await getDownloadURL(storageRef);
  
      console.log("Image uploaded successfully!");
      return downloadURL;
    } catch (error) {
      console.error("Error uploading image:", error);
      return null;
    }
  };

  // reload page and queries
  const isFocused = useIsFocused();
  useEffect(() => {
    // Fetch data when the screen is focused or on component mount
    if (isFocused) {
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]); // Run when isFocused changes

  const updateBackground = async (color) => {
    try {

      console.log("updating background...");
      const washingtonRef = doc(db, "users", auth.currentUser.uid);

      await updateDoc(washingtonRef, {
        background: color,
        backgroundChoice: "Color",
      });

      fetchColors(auth.currentUser.uid);
    } catch (error) {
      console.error("Error updating background color: ", error);
    }
  };

  const updateButton = async (color) => {
    console.log("updating button...");
    const washingtonRef = doc(db, "users", auth.currentUser.uid);

    await updateDoc(washingtonRef, {
      button: color,
    });
    fetchColors(auth.currentUser.uid);
  };

  const updateText = async (color) => {
    console.log("updating text...");
    const washingtonRef = doc(db, "users", auth.currentUser.uid);

    await updateDoc(washingtonRef, {
      text: color,
    });
    fetchColors(auth.currentUser.uid);
  };

  const [backgroundColor, setBackgroundColor] = useState("");
  const [buttonColor, setButtonColor] = useState("");
  const [textColor, setTextColor] = useState("");

  const handleBackgroundChangeButton = () => {
    changeBackgroundImage(null);
    updateBackground(backgroundColor);
  };

  const handleButtonChangeButton = () => {
    updateButton(buttonColor);
  };

  const handleTextChangeButton = () => {
    updateText(textColor);
  };

  const handleResetChangeButton = async () => {
    changeBackgroundImage("Animals");
    updateButton("#FFA500");
    updateText("black");

    const userRef = doc(db, "users", auth.currentUser.uid);

    await updateDoc(userRef, {
      backgroundChoice: 'Animals',
    });
  };

  return (
    <View style={[bgStyles.container, { backgroundColor: userBackground }]}>
      {backgroundImage && (
        <Image
          source={{ uri: backgroundImage }}
          style={styles.backgroundImage}
        />
      )}
      <View style={styles.container}>
        <Text style={[styles.title, { backgroundColor: userButton, color: userText }]}>
          Create Custom Background
        </Text>
      </View>
      <ScrollView
        style={[styles.scrollView, { borderColor: userButton }]}
        contentContainerStyle={{ flexGrow: 1, paddingBottom: 300 }}
      >
        <View style={styles.buttonLabelContainer}>
          <Text style={[styles.label, { backgroundColor: userButton, color: userText }]}>
            Choose Background Color
          </Text>
        </View>
        <View style={styles.colorPickerContainer}>
          <ColorPicker
            color={backgroundColor}
            onColorChange={(color) => setBackgroundColor(color)}
            thumbSize={35}
            sliderSize={35}
            noSnap={true}
            row={true}
            swatches={true}
            swatchesLast={false}
            gapSize={0}
            discreteLength={0}
          />
          <TouchableOpacity
            onPress={handleBackgroundChangeButton}
            style={styles.backButton}>
            <Text style={[styles.backButtonText]}> Click to Change Background Color </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.buttonLabelContainer}>
          <Text style={[styles.label, { backgroundColor: userButton, color: userText }]}>
            Choose Button/Label Color
          </Text>
        </View>
        <View style={styles.colorPickerContainer}>
          <ColorPicker
            color={buttonColor}
            onColorChange={(color) => setButtonColor(color)}
            thumbSize={35}
            sliderSize={35}
            noSnap={true}
            row={true}
            swatches={true}
            swatchesLast={false}
            gapSize={0}
            discreteLength={0}
          />
          <TouchableOpacity
            onPress={handleButtonChangeButton}
            style={styles.backButton}>
            <Text style={[styles.backButtonText]}>  Click to Change Button Color </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.buttonLabelContainer}>
          <Text style={[styles.label, { backgroundColor: userButton, color: userText }]}>
            Choose Text Color
          </Text>
        </View>
        <View style={styles.colorPickerContainer}>
          <ColorPicker
            color={textColor}
            onColorChange={(color) => setTextColor(color)}
            thumbSize={35}
            sliderSize={35}
            noSnap={true}
            row={true}
            swatches={true}
            swatchesLast={false}
            gapSize={0}
            discreteLength={0}
          />

          <TouchableOpacity
            onPress={handleTextChangeButton}
            style={styles.backButton}>
            <Text style={[styles.backButtonText]}>  Click to Change Text Color </Text>
          </TouchableOpacity>

        </View>

        <View style={styles.labelContainer}>
          <TouchableOpacity
            onPress={pickImage}
            style={[styles.button, { backgroundColor: userButton }]}
          >
            <Text style={[styles.buttonText, { color: userText }]}>
              Choose Your Own Background Image{" "}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.labelContainer}>
          <TouchableOpacity
            onPress={handleResetChangeButton}
            style={[styles.button, { backgroundColor: userButton }]}
          >
            <Text style={[styles.buttonText, { color: userText }]}>
              Restore Default Colors and Background{" "}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <View style={{ opacity: Platform.OS === 'android' ? 0 : 10, pointerEvents: Platform.OS === 'android' ? 'none' : "auto", height: "6%", marginBottom: "5%", }}>
        <TouchableOpacity
          onPress={() => navigation.navigate("SettingsScreen")}
          style={styles.backButton}
        >
          <Text style={styles.backButtonText}> Return to Settings Screen </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
  },

  container: {
    marginTop: 70,
    padding: 25,
    justifyContent: "center",
    alignItems: "center",
    //paddingBottom: "10%",
  },
  userContainer: {
    backgroundColor: "white",
    flex: 1,
    resizeMode: "cover", // You can change this to "contain" or other values based on your image requirements
  },

  scrollView: {
    marginHorizontal: 10,
    marginTop: 20,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#FFA500",
  },

  colorPickerContainer: {
    height: "30%",
    width: "80%",
    marginRight: "15%",
    marginLeft: "15%",
    paddingBottom: 15,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
  },

  buttonLabelContainer: {
    height: "5%",
    paddingBottom: 15,
    alignItems: "center",
    justifyContent: "center",
  },

  labelContainer: {
    height: "10%",
    marginTop: "5%",
    paddingBottom: 0,
    alignItems: "center",
  },

  title: {
    backgroundColor: "#FFA500",
    width: 250,
    textAlign: "center",
    marginTop: 0,
    fontSize: 24,
    fontWeight: "bold",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  label: {
    backgroundColor: "#FFA500",
    width: 350,
    height: 21,
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  buttonContainer: {
    height: "5%",
    flexDirection: "row",
    justifyContent: "center",
    //alignItems: "center",
    paddingHorizontal: 10,
    marginBottom: "5%",
  },

  button: {
    backgroundColor: "#FFA500",
    width: "60%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    top: "10%",
    textAlign: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  buttonText: {
    color: "black",
    fontWeight: "bold",
    fontSize: 16,
    textAlign: "center",
  },

  backButton: {
    width: "100%",
    padding: 15,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
  },

  backButtonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },

  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },
});

export default CreateBackgroundScreen;
