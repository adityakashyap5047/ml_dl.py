import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import React, { useState, useEffect } from "react";
import {
  ServerContainer,
  useIsFocused,
  useRoute,
} from "@react-navigation/native";
import {
  auth,
  db,
  getDocs,
  collection,
  query,
  where,
  deleteDoc,
  doc,
} from "../firebase";
import {
  StyleSheet,
  Text,
  SafeAreaView,
  ScrollView,
  StatusBar,
  Image,
  TouchableOpacity,
  View,
  Alert,
  Platform,
} from "react-native";
import { useUserPreferences } from "../src/UserPreferencesContext";

const CompletedGoalsScreen = ({ navigation }) => {
  //gets background
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const isURLImage =
    typeof backgroundImage === "string" && backgroundImage.startsWith("http");

  const { userBackground, userButton, userText, fetchColors } =
    useUserPreferences();

  //get current user id
  const uid = auth.currentUser.uid;

  //reload data every time you navigate to this page
  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      fetchUserGoals();
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]);

  // array to store all the goals
  const [goalChecklist, setGoalChecklist] = useState([]);

  //database queries
  const fetchUserGoals = async () => {
    console.log("fetching...");

    // gets the goals that are linked to the current user
    const goalIds = [];
    const q = query(collection(db, "userGoals"), where("userID", "==", uid));
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      goalIds.push({
        id: doc.data().goalID,
      });
    });

    //get the description of the user goals from the correct category
    const goalDescriptions = [];
    const q2 = query(collection(db, "goals"), where("completed", "==", true));
    const querySnapshot2 = await getDocs(q2);
    querySnapshot2.forEach((doc) => {
      if (goalIds.some((goal) => goal.id === doc.id)) {
        const timestamp = doc.data().dateOfCompletion;
        const dateObject = timestamp.toDate();
        const formattedDate = dateObject.toLocaleDateString("en-US", {
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
        });
        goalDescriptions.push({
          id: doc.id,
          description: doc.data().description,
          dateOfCompletion: formattedDate,
          section: doc.data().section,
          category: doc.data().category,
        });
      }
    });
    console.log(goalDescriptions);
    goalDescriptions.sort((a, b) => {
      const dateA = new Date(a.dateOfCompletion.split("/").reverse().join("-"));
      const dateB = new Date(b.dateOfCompletion.split("/").reverse().join("-"));
      return dateB - dateA; // Use dateB - dateA for descending order, use dateA - dateB for ascending order
    });
    setGoalChecklist(goalDescriptions);
  };

  // Handle Action to complete Goal
  const handleDeleteGoal = async (goal) =>
    Alert.alert("Are you sure you want to Delete this Accomplishment?", "", [
      {
        text: "Cancel",
        onPress: () => console.log("Cancel Pressed"),
        style: "cancel",
      },
      {
        text: "Delete",
        onPress: () => {
          console.log("Delete Pressed");
          deleteGoal(goal);
        },
      },
    ]);

  // Handle Action to complete Goal
  const deleteGoal = async (goalId) => {
    const goalIdsToDelete = [];
    const q = query(collection(db, "userGoals"), where("goalID", "==", goalId));

    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      goalIdsToDelete.push(doc.id);
    });
    for (const deleteGoalId of goalIdsToDelete) {
      try {
        console.log(deleteGoalId);
        await deleteDoc(doc(db, "userGoals", deleteGoalId));
        console.log(
          `Document with goalId ${deleteGoalId} in userGoals deleted successfully.`
        );
      } catch (error) {
        console.error(
          `Error deleting document with goalId ${deleteGoalId} in userGoals:`,
          error
        );
      }
    }
    try {
      await deleteDoc(doc(db, "goals", goalId));
      console.log(
        `Document with goalId ${goalId} in goals deleted successfully.`
      );
    } catch (error) {
      console.error(
        `Error deleting document with goalId ${goalId} in goals:`,
        error
      );
    }
    fetchUserGoals();
  };

  return (
    <View style={[bgStyles.container, { backgroundColor: userBackground }]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />
      <SafeAreaView style={styles.container}>
        <Text
          style={[
            styles.text,
            { backgroundColor: userButton, color: userText },
          ]}
        >
          My Completed Goals
        </Text>

        <ScrollView
          style={[styles.scrollView, { backgroundColor: userButton }]}
        >
          {goalChecklist.map((goal, index) => (
            <TouchableOpacity
              onPress={() =>
                navigation.navigate("CertificateScreen", {
                  goalId: goal.id,
                })
              }
              onLongPress={() => handleDeleteGoal(goal.id)}
              style={styles.button}
              key={index}
            >
              <View style={{ flexDirection: "row" }}>
                <View style={[styles.checkboxContainer, { width: "60%" }]}>
                  <Text style={[styles.checkboxText, { color: userText }]}>
                    {goal.description}
                  </Text>
                </View>

                <View style={[styles.checkboxContainer, { marginLeft: "12%" }]}>
                  <Text style={[styles.checkboxText, { color: userText }]}>
                    {goal.dateOfCompletion}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View
          style={{
            opacity: Platform.OS === "android" ? 0 : 10,
            pointerEvents: Platform.OS === "android" ? "none" : "auto",
          }}
        >
          <TouchableOpacity
            onPress={() => navigation.navigate("ProfileScreen")}
          >
            <Text style={styles.buttonText}> Return to Profile </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover",
  },

  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
  },

  buttonContainer: {
    marginTop: "5%",
  },

  scrollView: {
    flex: 1,
    backgroundColor: "#FFA500",
    marginHorizontal: "3%",
    marginTop: "10%",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    marginBottom: 20,
  },

  text: {
    backgroundColor: "#FFA500",
    fontSize: 32,
    paddingHorizontal: 20,
    marginTop: "5%",
    alignSelf: "center",
    textAlign: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  checkboxText: {
    flex: 1,
    flexWrap: "wrap",
    paddingVertical: "2%",
  },

  button: {
    height: "10%",
    width: "100%",
    borderRadius: 10,
    left: "3%",
    //alignItems: "center",
    paddingVertical: "2%",
  },

  buttonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },

  checkboxContainer: {
    //backgroundColor: 'white',
    //height: "5%",
    //flexShrink: 1,
    //justifyContent: "center",
    //paddingHorizontal: 10,
    //paddingVertical: "25%",
    marginBottom: Platform.isPad ? "50%" : "100%",
  },
});

export default CompletedGoalsScreen;
