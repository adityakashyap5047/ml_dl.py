import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  Text,
  SafeAreaView,
  StatusBar,
  Image,
  TouchableOpacity,
  View,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
  Alert,
} from "react-native";
import {
  db,
  doc,
  getDoc,
  deleteDoc,
  collection,
  query,
  where,
  getDocs,
  serverTimestamp,
  updateDoc,
  auth,
} from "../firebase";
import { useIsFocused, useRoute } from "@react-navigation/native";
import { useUserPreferences } from "../src/UserPreferencesContext";
import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";

const GoalProgressScreen = ({ navigation }) => {
  // get background
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const isURLImage =
    typeof backgroundImage === "string" && backgroundImage.startsWith("http");

  //get goalId and section (home/school)
  const route = useRoute();
  const goalId = route.params.goalId;
  const section = route.params.section;
  const { userBackground, userButton, userText, fetchColors } =
    useUserPreferences();

  //get current user id
  const uid = auth.currentUser.uid;

  // reload data everytime you navigate to this screen
  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      fetchUserGoals();
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]);

  //database queries
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [isChecked, setIsChecked] = useState(false);
  const [notes, setNotes] = useState("");
  const [home, setHome] = useState(0);
  const [school, setSchool] = useState(0);
  const fetchUserGoals = async () => {
    console.log("fetching...");

    const docRef = doc(db, "goals", goalId);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      console.log("Document data:", docSnap.data());
      setCategory(docSnap.data().category);
      setDescription(docSnap.data().description);
      setIsChecked(docSnap.data().isChecked);
      setNotes(docSnap.data().note);
    } else {
      console.log("No such document!");
    }
    const docRef2 = doc(db, "users", uid);
    const docSnap2 = await getDoc(docRef2);

    if (docSnap2.exists()) {
      console.log("Document data:", docSnap2.data());
      setHome(docSnap2.data().home);
      setSchool(docSnap2.data().school);
    } else {
      console.log("No such document!");
    }
  };
  const handleSaveGoal = async () => {
    console.log(goalId);
    const docRef = doc(db, "goals", goalId);

    // Set the "capital" field of the city 'DC'
    await updateDoc(docRef, {
      note: notes,
    });
  };
  const handleCompleteGoal = async () => {
    console.log(goalId);
    const docRef = doc(db, "goals", goalId);

    // Set the "capital" field of the city 'DC'
    await updateDoc(docRef, {
      completed: true,
      dateOfCompletion: serverTimestamp(),
    });
    try {
      const updateRef = doc(db, "users", uid);

      // Set the "capital" field of the city 'DC'
      if (section == "Home") {
        await updateDoc(updateRef, {
          home: home - 1,
        });
      } else {
        await updateDoc(updateRef, {
          school: school - 1,
        });
      }
    } catch (error) {
      console.error(`Error updating profile counter`, error);
    }
    navigation.navigate("CertificateScreen", {
      goalId: goalId,
    });
  };

  const handleDeleteGoal = async () =>
    Alert.alert("Delete?", "Do you want to Delete this goal?", [
      {
        text: "Cancel",
        onPress: () => console.log("Cancel Pressed"),
        style: "cancel",
      },
      {
        text: "Delete",
        onPress: () => {
          console.log("Delete Pressed");
          deleteGoal();
        },
      },
    ]);
  const deleteGoal = async () => {
    console.log(goalId);
    const goalIdsToDelete = [];
    const q = query(collection(db, "userGoals"), where("goalID", "==", goalId));

    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      goalIdsToDelete.push(doc.id);
    });
    console.log(goalIdsToDelete);
    for (const deleteGoalId of goalIdsToDelete) {
      try {
        console.log(deleteGoalId);
        await deleteDoc(doc(db, "userGoals", deleteGoalId));
        console.log(
          `Document with goalId ${deleteGoalId} in userGoals deleted successfully.`
        );
      } catch (error) {
        console.error(
          `Error deleting document with goalId ${deleteGoalId} in userGoals:`,
          error
        );
      }
    }
    try {
      await deleteDoc(doc(db, "goals", goalId));
      console.log(
        `Document with goalId ${goalId} in goals deleted successfully.`
      );
    } catch (error) {
      console.error(
        `Error deleting document with goalId ${goalId} in goals:`,
        error
      );
    }
    try {
      const updateRef = doc(db, "users", uid);

      // Set the "capital" field of the city 'DC'
      if (section == "Home") {
        await updateDoc(updateRef, {
          home: home - 1,
        });
      } else {
        await updateDoc(updateRef, {
          school: school - 1,
        });
      }
    } catch (error) {
      console.error(`Error updating profile counter`, error);
    }
    navigation.navigate("MyGoalsScreen");
  };

  return (
    <View style={[bgStyles.container]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />
      <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
        <SafeAreaView style={styles.container}>
          <Text
            style={[
              styles.title,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            {description} Progress
          </Text>

          <Text
            style={[
              styles.label,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Category: {category}
          </Text>

          {/* Dreams */}
          <Text
            style={[
              styles.labelLong,
              { backgroundColor: userButton, color: userText },
            ]}
          >
            Enter Notes for Completing Goal
          </Text>
          <TextInput
            style={styles.inputBox}
            placeholder="Enter Notes Here:"
            value={notes}
            onChangeText={(text) => {
              setNotes(text);
            }}
            multiline={true}
          />

          <View style={[styles.buttonContainer]}>
            <TouchableOpacity onPress={handleSaveGoal}>
              <Text
                style={[
                  styles.text,
                  { backgroundColor: userButton, color: userText },
                ]}
              >
                Save Notes
              </Text>
            </TouchableOpacity>
          </View>
          <View style={[styles.buttonContainer]}>
            <TouchableOpacity onPress={handleCompleteGoal}>
              <Text
                style={[
                  styles.text,
                  { backgroundColor: userButton, color: userText },
                ]}
              >
                Mark Goal Completed
              </Text>
            </TouchableOpacity>
          </View>

          <View style={[styles.buttonContainer]}>
            <TouchableOpacity onPress={handleDeleteGoal}>
              <Text
                style={[
                  styles.text,
                  { backgroundColor: userButton, color: userText },
                ]}
              >
                Delete this Goal
              </Text>
            </TouchableOpacity>
          </View>

          <View
            style={{
              opacity: Platform.OS === "android" ? 0 : 10,
              pointerEvents: Platform.OS === "android" ? "none" : "auto",
            }}
          >
            <TouchableOpacity
              onPress={() => navigation.navigate("MyGoalsScreen")}
            >
              <Text style={styles.backButtonText}>
                {" "}
                Return to Goals Screen{" "}
              </Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </TouchableWithoutFeedback>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover", // You can change this to "contain" or other values based on your image requirements
  },

  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
  },

  scrollView: {
    backgroundColor: "#FFA500",
    marginHorizontal: 10,
    marginTop: 120,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    marginBottom: 10,
  },

  title: {
    backgroundColor: "#FFA500",
    fontSize: 24,
    marginHorizontal: 5,
    marginTop: "10%",
    textAlign: "center",
    fontWeight: "bold",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  text: {
    backgroundColor: "#FFA500",
    fontSize: 32,
    marginHorizontal: 5,
    //marginTop: "15%",
    textAlign: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  buttonContainer: {
    alignSelf: "center",
    width: "100%",
    marginTop: "10%",
  },

  button: {
    //backgroundColor: "#FFA500",
    width: "100%",
    //padding: 15,
    //paddingVertical: 10,
    borderRadius: 10,
    //alignItems: "center",
  },

  buttonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
  },

  inputBox: {
    width: "90%",
    height: "20%",
    alignSelf: "center",
    marginVertical: 10,
    padding: 10,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: "white",
    borderColor: "black",
  },

  label: {
    backgroundColor: "#FFA500",
    width: 250,
    alignSelf: "center",
    textAlign: "center",
    marginTop: "5%",
    fontSize: 18,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  labelLong: {
    backgroundColor: "#FFA500",
    width: "90%",
    alignSelf: "center",
    textAlign: "center",
    marginTop: "10%",
    fontSize: 18,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "black",
    overflow: "hidden",
  },

  backButtonText: {
    color: "white",
    marginTop: "10%",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },
});

export default GoalProgressScreen;
