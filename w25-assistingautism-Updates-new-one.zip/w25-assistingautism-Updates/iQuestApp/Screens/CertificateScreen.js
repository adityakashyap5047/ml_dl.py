import React, { useState, useEffect, useRef } from "react";
import {
  StyleSheet,
  Text,
  StatusBar,
  Image,
  TouchableOpacity,
  View,
  Alert,
  Platform,
} from "react-native";
import {
  db,
  doc,
  getDoc,
  deleteDoc,
  collection,
  query,
  where,
  getDocs,
  auth,
  updateDoc,
  serverTimestamp,
} from "../firebase";
import { useIsFocused, useRoute } from "@react-navigation/native";
import { useUserPreferences } from "../src/UserPreferencesContext";
import { useTheme } from "../src/ThemeContext";
import { themeStyles } from "../src/styles";
import certificate from "../assets/Certificate.png";
import LottieView from "lottie-react-native"; // https://dev.to/barrymichaeldoyle/react-native-tutorial-how-to-implement-a-celebration-confetti-burst-3if2
import ConfettiCannon from "react-native-confetti-cannon"; // https://github.com/VincentCATILLON/react-native-confetti-cannon

let firstTime = 1;

const CertificateScreen = ({ navigation }) => {
  // get background
  const { theme, backgroundImage } = useTheme();
  const bgStyles = themeStyles[theme];
  const isURLImage =
    typeof backgroundImage === "string" && backgroundImage.startsWith("http");

  //const confettiRef = useRef<LottieView>(null);

  function triggerConfetti() {
    confettiRef.current?.play(0);
  }

  //get goalId and section (home/school)
  const route = useRoute();
  const goalId = route.params.goalId;
  const { userBackground, userButton, userText, fetchColors } =
    useUserPreferences();

  // reload data every time you navigate to this screen
  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      fetchUserGoals();
      fetchData();
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]);

  //database queries
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [isChecked, setIsChecked] = useState(false);
  const [first, setFirst] = useState("");
  const [last, setLast] = useState("");

  const fetchUserGoals = async () => {
    console.log("fetching...");

    const docRef = doc(db, "goals", goalId);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      console.log("Document data:", docSnap.data());
      setCategory(docSnap.data().category);
      setDescription(docSnap.data().description);
      setIsChecked(docSnap.data().isChecked);
    } else {
      console.log("No such document!");
    }
  };

  const fetchData = async () => {
    console.log("fetching...");
    try {
      const querySnapshot = await getDocs(
        query(
          collection(db, "users"),
          where("email", "==", auth.currentUser.email)
        )
      );

      // Check if there are documents in the querySnapshot
      if (!querySnapshot.empty) {
        console.log("Documents found:", querySnapshot.size);

        querySnapshot.forEach((doc) => {
          setFirst(doc.data().first);
          setLast(doc.data().last);
        });
      } else {
        console.log("No documents found matching the query.");
      }
    } catch (error) {
      console.error("Error fetching data: ", error);
    }
  };


  if (firstTime == 1) {
    Alert.alert(
      "Screenshot Your Achievement to Share with Friends and Family",
      "",
      [
        {
          text: "Continue",
          onPress: () => {
            //navigation.navigate("Home");
          },
          //style: "cancel",
        },
      ]
    );
    firstTime = firstTime + 1;
  }

  return (
    <View style={[bgStyles.container]}>
      <Image source={{ uri: backgroundImage }} style={styles.backgroundImage} />

      <LottieView
        source={require("../assets/confetti.json")}
        autoPlay={true}
        loop={true}
        style={styles.lottie}
        resizeMode="cover"
      />

      <Text style={[styles.title, { color: userText }]}>CONGRATULATIONS!</Text>

      <Image source={certificate} style={styles.icon}></Image>

      <Text style={[styles.name, { color: userText }]}>
        {first} {last}
      </Text>

      <Text style={[styles.description, { color: userText }]}>
        {description}
      </Text>

      <ConfettiCannon
        count={400}
        origin={{ x: -10, y: 0 }}
        fallSpeed={5000}
        autoStart={true}
      />

      <View
        style={{
          opacity: Platform.OS === "android" ? 0 : 10,
          pointerEvents: Platform.OS === "android" ? "none" : "auto",
        }}
      >
        <TouchableOpacity
          onPress={() => navigation.navigate("CompletedGoalsScreen")}
        >
          <Text style={styles.backButtonText}> See Completed Goals </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: "cover", // You can change this to "contain" or other values based on your image requirements
  },

  backgroundImage: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    resizeMode: "stretch",
  },

  lottie: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1000,
    pointerEvents: "none",
  },

  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
  },

  certificateContainer: {
    height: "10%",
    marginTop: "50%",
    paddingBottom: 0,
    alignItems: "center",
  },

  buttonContainer: {
    alignSelf: "center",
    width: "100%",
    marginTop: "10%",
  },

  backButtonText: {
    position: "absolute",
    color: "white",
    marginTop: Platform.isPad ? "100%" : "150%",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
    textShadowColor: "black",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
    alignSelf: "center",
  },

  icon: {
    position: "absolute",
    height: Platform.isPad ? "60%" : "40%",
    width: "100%",
    alignSelf: "center",
    marginTop: Platform.isPad ? "30%" : "60%",
  },

  title: {
    width: 350,
    textAlign: "center",
    marginTop: Platform.isPad ? "10%" : "25%",
    fontSize: 32,
    fontWeight: "bold",
    alignSelf: "center",
  },

  name: {
    position: "absolute",
    width: 350,
    textAlign: "center",
    marginTop: Platform.isPad ? "62%" : "93%",
    fontSize: Platform.isPad ? 24 : 16,
    fontWeight: "bold",
    alignSelf: "center",
    fontStyle: "italic",
  },

  description: {
    position: "absolute",
    width: Platform.isPad ? "80%" : 350,
    textAlign: "center",
    marginTop: Platform.isPad ? "72%" : "102%",
    fontSize: Platform.isPad ? 16 : 12,
    fontWeight: "bold",
    alignSelf: "center",
  },
});

export default CertificateScreen;
