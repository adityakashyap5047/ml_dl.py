// firebase.js
import { initializeApp, firebase } from "firebase/app";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";
import {
  getFirestore,
  collection,
  addDoc,
  setDoc,
  getDocs,
  getDoc,
  query,
  where,
  FieldPath,
  doc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
} from "firebase/firestore";
import { initializeAuth, getReactNativePersistence } from "firebase/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { getStorage, ref } from "firebase/storage";

import "firebase/auth";
import "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD8vnHtQqgyv9BE09-yXaX8Kq3ZiPyUqWo",
  authDomain: "iquest-24a4b.firebaseapp.com",
  projectId: "iquest-24a4b",
  storageBucket: "iquest-24a4b.appspot.com",
  messagingSenderId: "458712427535",
  appId: "1:458712427535:web:c8d7dc728799bcba55c77a",
};

const firebaseApp = initializeApp(firebaseConfig);

// const auth = getAuth();

const auth = initializeAuth(firebaseApp, {
  persistence: getReactNativePersistence(AsyncStorage),
});

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(firebaseApp);

//initialize Firebase Storage
export const storage = getStorage();

export {
  auth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  db,
  collection,
  addDoc,
  setDoc,
  getDocs,
  getDoc,
  query,
  where,
  doc,
  updateDoc,
  FieldPath,
  deleteDoc,
  serverTimestamp,
};

export default { firebaseApp };
