// App.js
import React, { useEffect } from "react";
import Navigation from "./Navigation";
import { ThemeProvider } from "./src/ThemeContext";
import * as ImagePicker from "expo-image-picker";
import { CategoriesProvider } from "./src/CategoriesContext";
import { ProfileProvider } from "./src/ProfileContext";
import { UserPreferencesProvider } from "./src/UserPreferencesContext";

const App = () => {
  // You don't need to initialize Firebase here anymore
  useEffect(() => {
    (async () => {
      const { status } =
        await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== "granted") {
        console.log("Permission to access camera roll is required");
      }
    })();
  }, []);

  return (
    <ThemeProvider>
      <ProfileProvider>
        <CategoriesProvider>
          <UserPreferencesProvider>
            <Navigation />
          </UserPreferencesProvider>
        </CategoriesProvider>
      </ProfileProvider>
    </ThemeProvider>
  );
};

export default App;
