// UserPreferencesContext.js
import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db, doc, getDoc } from '../firebase';

const UserPreferencesContext = createContext();

export const UserPreferencesProvider = ({ children }) => {
  const [userBackground, setUserBackground] = useState('white');
  const [userButton, setUserButton] = useState('#FFA500');
  const [userText, setUserText] = useState('black');
  const [loading, setLoading] = useState(true);

  const fetchColors = async (uid) => {
    try {
      const docRef = doc(db, 'users', uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const backgroundChoice = docSnap.data().backgroundChoice;

        if (backgroundChoice === 'Color') {
          // If backgroundChoice is set to "Color", use the "background" field
          setUserBackground(docSnap.data().background);
        } 
        else if (backgroundChoice == 'Custom'){
          // if backgroundChoice is set to 'Custom', use the "customBackground" field
          setUserBackground(docSnap.data().customBackground);
        }
        else {
          // If backgroundChoice is not "Color", use the "backgroundChoice" field
          setUserBackground(backgroundChoice);
        }

        setUserButton(docSnap.data().button);
        setUserText(docSnap.data().text);
      } else {
        console.log('No user preferences document found!');
      }

      setLoading(false);
    } catch (error) {
      console.error('Error fetching user preferences: ', error);
      setLoading(false);
    }
  };


  useEffect(() => {
    const handleAuthStateChanged = async () => {
      auth.onAuthStateChanged((user) => {
        if (user) {
          // User is signed in, fetch preferences
          //console.log("fetching user preferences....")
          fetchColors(user.uid);
        } else {
          // User is signed out, set loading to false
          setLoading(false);
        }
      });
    };

    handleAuthStateChanged();
  }, []);

  if (loading) {
    return null;
  }

  //console.log('Rendering UserPreferencesProvider...');

  return (
    <UserPreferencesContext.Provider
      value={{ userBackground, setUserBackground, userButton, setUserButton, userText, setUserText, fetchColors }}
    >
      {children}
    </UserPreferencesContext.Provider>
  );
};

export const useUserPreferences = () => useContext(UserPreferencesContext);
