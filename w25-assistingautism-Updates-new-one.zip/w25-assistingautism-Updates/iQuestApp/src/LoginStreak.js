// LoginStreak.js

import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useIsFocused } from '@react-navigation/native';
import { doc, updateDoc, getDoc, auth, db } from '../firebase';
import { differenceInDays } from 'date-fns'; // https://docs.w3cub.com/date_fns/differenceInDays.html
import { useUserPreferences } from "./UserPreferencesContext";

const LoginStreak = () => {
    const [streak, setStreak] = useState(0);
    const userId = auth.currentUser?.uid; // Initialize with the UID
    const isFocused = useIsFocused();
    const { userText, fetchColors } = useUserPreferences();

    const updateStreak = async () => {
        try {
            const userRef = doc(db, 'users', userId);

            const userDoc = await getDoc(userRef);

            if (userDoc.exists()) {
                // Set lastLoginDate to yesterday for testing
                // const yesterday = new Date();
                // yesterday.setDate(yesterday.getDate() - 1);

                // const lastLoginDate = userDoc.data().lastLogin?.toDate() || yesterday;
                const lastLoginDate = userDoc.data().lastLogin?.toDate() || null;

                // toDateString() gets rid of time component in date
                const today = new Date(new Date().toDateString());
                
                const daysSinceLastLogin = differenceInDays(today, lastLoginDate);

                // console.log(`Last Login Date: ${lastLoginDate}`);
                // console.log(`Today: ${today}`);
                // console.log(`daysSinceLastLogin: ${daysSinceLastLogin}`);

                // User missed a day or hasn't logged in before, reset streak
                if (!lastLoginDate || daysSinceLastLogin > 1) {
                    console.log(`User missed a day`);
                    await updateDoc(userRef, { streak: 1, lastLogin: today });
                    setStreak(1);
                } 
                // User logged in consecutively
                else if (daysSinceLastLogin === 1) {
                    console.log(`Update streak`);
                    const newStreak = (userDoc.data().streak || 0) + 1;
                    await updateDoc(userRef, { streak: newStreak, lastLogin: today });
                    setStreak(newStreak);
                }

                // User logged in within the same day
                else if (daysSinceLastLogin < 1){
                    const newStreak = (userDoc.data().streak || 0);
                    setStreak(newStreak);
                }
                
            }
        } catch (error) {
            console.error('Error updating streak: ', error);
        }
    };

    useEffect(() => {
        if (isFocused) {
            updateStreak();
            fetchColors(auth.currentUser.uid);
        }
    }, [isFocused]);

    // Return JSX to display the streak
    return (
        <View style={styles.streakContainer}>
            <Text style={[styles.streakText, { color: userText, textDecorationLine: 'underline', }]}>
                Login Streak: 
            </Text>
            <Text style={[styles.streakText, { color: userText }]}>
            {"   "}{streak}🔥
            </Text>
        </View>
    );
};

const styles = StyleSheet.create({
    streakContainer: {
        marginTop: "15%",
        alignItems: 'center',
        flexDirection: "row"
    },
    streakText: {
        fontSize: 25,
        fontWeight: "bold",
        textAlign: "center",
        fontStyle: 'italic',
    },
});

export default LoginStreak;

