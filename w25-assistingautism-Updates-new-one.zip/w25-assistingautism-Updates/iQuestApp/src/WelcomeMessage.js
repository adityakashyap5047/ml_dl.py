import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet } from "react-native";
import { auth, db, getDocs, collection, query, where, getDoc } from "../firebase";
import { useIsFocused } from "@react-navigation/native";
import { useUserPreferences } from "./UserPreferencesContext";
import LoginStreak from "./LoginStreak";

const WelcomeMessage = () => {
  const { userText, fetchColors } = useUserPreferences();
  const isFocused = useIsFocused();
  const [first, setFirst] = useState("");

  const fetchData = async () => {
    try {
      const querySnapshot = await getDocs(
        query(
          collection(db, "users"),
          where("email", "==", auth.currentUser.email)
        )
      );

      querySnapshot.forEach((doc) => {
        setFirst(doc.data().first);
      });
    } catch (error) {
      console.error("Error fetching data: ", error);
    }
  };

  //an idea here could be to list their current streak?
  const messages = [
    `Welcome To iQuest, ${first}!`,
    `Hello ${first}!`,
    `Greetings, ${first}!`,
  ];

  const randomIndex = Math.floor(Math.random() * messages.length);
  const selectedMessage = messages[randomIndex];

  useEffect(() => {
    // Fetch data when the screen is focused or on component mount
    if (isFocused) {
      fetchData();
      fetchColors(auth.currentUser.uid);
    }
  }, [isFocused]); // Run when isFocused changes

  return (
    <View style={styles.container}>
      <Text style={[styles.text, { color: userText }]}>{selectedMessage}</Text>
      <LoginStreak/>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    top: "15%",
    left: 0,
    right: 0,
    alignItems: "center",
  },
  text: {
    fontSize: 36,
    fontWeight: "bold",
    textAlign: "center", 
  },
});

export default WelcomeMessage;
