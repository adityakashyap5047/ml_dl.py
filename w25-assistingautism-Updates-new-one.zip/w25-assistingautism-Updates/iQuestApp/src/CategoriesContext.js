import React, { createContext, useContext, useState, useEffect } from 'react';
import { db, collection, getDocs } from "../firebase";

const CategoriesContext = createContext();

export const CategoriesProvider = ({ children }) => {
  const [homeCategories, setHomeCategories] = useState([]);
  const [schoolCategories, setSchoolCategories] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const tempHomeCategories = [];
    const tempSchoolCategories = [];

    try {
      const querySnapshot = await getDocs(collection(db, 'defaultGoals'));

      querySnapshot.forEach((doc) => {
        if (doc.data().section === 'Home' && !tempHomeCategories.includes(doc.data().category)) {
          tempHomeCategories.push(doc.data().category);
        } else if (doc.data().section === 'School' && !tempSchoolCategories.includes(doc.data().category)) {
          tempSchoolCategories.push(doc.data().category);
        }
      });

      const sortedHomeCategories = tempHomeCategories.sort();
      const sortedSchoolCategories = tempSchoolCategories.sort();

      setHomeCategories(sortedHomeCategories);
      setSchoolCategories(sortedSchoolCategories);
    } catch (error) {
      console.error('Error fetching data: ', error);
    }
  };

  return (
    <CategoriesContext.Provider value={{ homeCategories, schoolCategories }}>
      {children}
    </CategoriesContext.Provider>
  );
};

export const useCategories = () => {
  const context = useContext(CategoriesContext);
  if (!context) {
    throw new Error('useCategories must be used within a CategoriesProvider');
  }
  return context;
};
