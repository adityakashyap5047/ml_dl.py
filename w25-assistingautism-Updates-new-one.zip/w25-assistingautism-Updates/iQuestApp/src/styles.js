// styles.js
import { StyleSheet } from "react-native";


export const themeStyles = {
  default: StyleSheet.create({
    // Default theme styles
    container: {
      backgroundColor: "white",
      flex: 1,
      resizeMode: "cover", // You can change this to "contain" or other values based on your image requirements
    },
    backgroundImage: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      resizeMode: "cover",
    },
  }),

  blue: StyleSheet.create({
    container: {
      backgroundColor: "blue",
      flex: 1,
      resizeMode: "cover",
    },
  }),
  purple: StyleSheet.create({
    container: {
      backgroundColor: "purple",
      flex: 1,
      resizeMode: "cover",
    },
  }),
  red: StyleSheet.create({
    container: {
      backgroundColor: "red",
      flex: 1,
      resizeMode: "cover",
    },
  }),
 
};
