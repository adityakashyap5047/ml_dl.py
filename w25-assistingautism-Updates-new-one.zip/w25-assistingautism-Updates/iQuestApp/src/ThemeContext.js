// ThemeContext.js
import { createContext, useContext, useState, useEffect } from "react";
import { auth, doc, getDoc, db } from "../firebase";

const ThemeContext = createContext();

export function useTheme() {
  return useContext(ThemeContext);
}

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState("default");
  const [userId, setUserId] = useState(null); // Initialize with null
  const [backgroundImage, setBackgroundImage] = useState(
    "https://w0.peakpx.com/wallpaper/247/236/HD-wallpaper-africa-selfie-animals-cute-elephant-elephants-funny-lion-nature-safari-zebra.jpg"
  );

  useEffect(() => {
    const fetchBackgroundChoice = async () => {
      try {
        if (userId) {
          const userRef = doc(db, 'users', userId);
          const userDoc = await getDoc(userRef);

          if (userDoc.exists() && userDoc.data().backgroundChoice) {
            const userBackgroundChoice = userDoc.data().backgroundChoice;

            if (userBackgroundChoice === 'Custom'){
              const backgroundURI = userDoc.data().customBackground;
              changeBackgroundImage(backgroundURI);
            }
            else{
              changeBackgroundImage(userBackgroundChoice);
            }
          }
        }
      } catch (error) {
        console.error("Error fetching background choice: ", error);
      }
    };

    fetchBackgroundChoice();
  }, [userId]); // Run when userId changes

  // Set userId when authentication state changes
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        setUserId(user.uid);
      }
    });

    return () => unsubscribe();
  }, []);

  const changeTheme = (newTheme) => {
    setTheme(newTheme);
  };

  const changeBackgroundImage = (imageUri) => {
    const allowedBackgrounds = [
      "Animals",
      "Numbers",
      "Music",
      "Dinosaurs",
      "Anime",
      "Maps",
      "Trains",
    ];

    if (imageUri === null) {
      setBackgroundImage(
        "https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/HD_transparent_picture.png/1280px-HD_transparent_picture.png"
      );
    } else if (allowedBackgrounds.includes(imageUri)) {
      // You can set the background based on the imageUri
      // For example, set a different background image for each category.
      if (imageUri === "Animals") {
        setBackgroundImage(
          "https://w0.peakpx.com/wallpaper/247/236/HD-wallpaper-africa-selfie-animals-cute-elephant-elephants-funny-lion-nature-safari-zebra.jpg"
        );
      } else if (imageUri === "Numbers") {
        setBackgroundImage(
          "https://wallpaperaccess.com/full/1262292.jpg"
        );
      } else if (imageUri === "Music") {
        setBackgroundImage(
          "https://wallpapercave.com/wp/wp5240003.jpg"
        );
      } else if (imageUri === "Dinosaurs") {
        setBackgroundImage(
          "https://images.pixexid.com/a-4k-ultra-hd-mobile-wallpaper-showcasing-a-velociraptor-the-agile-dinosaur-wit-8jdb65of.jpeg"
        );
      } else if (imageUri === "Anime") {
        setBackgroundImage(
          "https://wallpapers.com/images/featured/aesthetic-anime-iphone-n7grgrxeoc2iz8x6.jpg"
        );
      } else if (imageUri === "Maps") {
        setBackgroundImage(
          "https://i.pinimg.com/originals/5b/93/75/5b9375a27984cbaf7c5615413e169215.jpg"
        );
      } else if (imageUri === "Trains") {
        setBackgroundImage(
          "https://www.teahub.io/photos/full/202-2021198_train-wallpaper-for-iphone.jpg"
        );
      } 
    } else {
      if (typeof imageUri === "string") {
        setBackgroundImage(imageUri);
      }
    }
  };

  return (
    <ThemeContext.Provider
      value={{ theme, changeTheme, backgroundImage, changeBackgroundImage }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

