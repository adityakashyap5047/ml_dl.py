// ProfileContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth, db, getDocs, query, where, collection } from '../firebase';

const ProfileContext = createContext();

export const useProfileContext = () => {
  return useContext(ProfileContext);
};

export const ProfileProvider = ({ children }) => {
  const [profileData, setProfileData] = useState({
    first: '',
    last: '',
    email: '',
    born: '',
    grade: '',
    profilePicture: '../Images/pp3.png',
    likes: '',
    dreams: ''
  });
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      // Check if there is an authenticated user
      if (auth.currentUser) {
        const querySnapshot = await getDocs(
          query(collection(db, 'users'), where('email', '==', auth.currentUser.email))
        );

        if (!querySnapshot.empty) {
          querySnapshot.forEach((doc) => {
            // Format the JavaScript Date object as a string
            const timestampInMilliseconds =
              doc.data().born.seconds * 1000 + Math.floor(doc.data().born.nanoseconds / 1000000);
            const date = new Date(timestampInMilliseconds);
            const formattedDate = date.toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            });

            setProfileData({
              first: doc.data().first,
              last: doc.data().last,
              email: doc.data().email,
              born: formattedDate,
              grade: doc.data().grade,
              profilePicture: doc.data().profilePicture,
              likes: doc.data().likes,
              dreams: doc.data().dreams,
            });

            setLoading(false);
          });
        } else {
          setLoading(false);
        }
      }
    } catch (error) {
      console.error('Error fetching data: ', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    const handleAuthStateChanged = async () => {
      auth.onAuthStateChanged((user) => {
        if (user) {
          // User is signed in, fetch data
          fetchData();
        } else {
          // User is signed out, set loading to false
          setLoading(false);
        }
      });
    };

    handleAuthStateChanged();
  }, []);

  const contextValue = {
    profileData,
    fetchData, // Expose the fetchData function to be used by components
  };

  if (loading) {
    return null; // or return a loading component
  }

  return <ProfileContext.Provider value={contextValue}>{children}</ProfileContext.Provider>;
};
