import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

// Screens
import HomeScreen from "./Screens/HomeScreen";
import LoginScreen from "./Screens/LoginScreen";
import TutorialScreen from "./Screens/TutorialScreen";
import ProfileScreen from "./Screens/ProfileScreen";
import GoalsScreen from "./Screens/GoalsScreen";
import MyGoalsScreen from "./Screens/MyGoalsScreen";
import CompletedGoalsScreen from "./Screens/CompletedGoalsScreen";
import AddGoalScreen from "./Screens/AddGoalScreen";
import CategoriesScreen from "./Screens/CategoriesScreen";
import SettingsScreen from "./Screens/SettingsScreen";
import RemindersScreen from "./Screens/ReminderScreen";
import RegisterScreen from "./Screens/RegisterScreen";
import GoalProgressScreen from "./Screens/GoalProgressScreen";
import CertificateScreen from "./Screens/CertificateScreen";
import CreateBackgroundScreen from "./Screens/CreateBackgroundScreen";

import EditProfileScreen from "./Screens/EditProfileScreen";

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const Navigation = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen
          options={{
            headerShown: false,
            gestureEnabled: false, //Disable the back swipe gesture
          }}
          name="Home"
          component={HomeScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="Login"
          component={LoginScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="Register"
          component={RegisterScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="Tutorial"
          component={TutorialScreen}
        />

        <Stack.Screen
          options={{ headerShown: false }}
          name="ProfileScreen"
          component={ProfileScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="EditProfileScreen"
          component={EditProfileScreen}
        />

        <Stack.Screen
          options={{ headerShown: false }}
          name="SettingsScreen"
          component={SettingsScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="GoalsScreen"
          component={GoalsScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="MyGoalsScreen"
          component={MyGoalsScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="CompletedGoalsScreen"
          component={CompletedGoalsScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="AddGoalScreen"
          component={AddGoalScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="CategoriesScreen"
          component={CategoriesScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="RemindersScreen"
          component={RemindersScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="CreateBackgroundScreen"
          component={CreateBackgroundScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="GoalProgressScreen"
          component={GoalProgressScreen}
        />
        <Stack.Screen
          options={{ headerShown: false }}
          name="CertificateScreen"
          component={CertificateScreen}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default Navigation;
