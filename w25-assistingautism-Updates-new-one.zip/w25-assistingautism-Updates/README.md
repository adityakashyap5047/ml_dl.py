# iQuest

## _Code Documentation_

App that allows users with autism and other disabilities and their caregivers to directly interact with a tool called the iQuest (iQuest = independence Quest). The purpose of the iQuest is to help users identify and practice independence goals they can work on at home or school.

## Table of Contents

1. [Features](#features)
2. [Tech](#tech)
3. [Installation](#installation)
4. [Usage](#usage)
5. [License](#license)

## Features

- Login/Register Authentication
- Cloud firestore database
- Firebase storage

## Tech

iQuest uses a number of open source projects to work properly:

- [expo] - Front end for the app
- [firebase] - Back end of the app
- [node.js] - evented I/O for the backend

## Installation

### Step 1: Download Expo Go on Your Mobile Device

- Download Expo Go on your mobile device from your app store.

### Step 2: Install a Code Editor like Visual Studio Code

- You can download Visual Studio Code from [here](https://code.visualstudio.com/download).

### Step 3: Install Node.js on Your Computer

To install Node.js, follow these steps based on your operating system: Windows, macOS.

#### Windows:

1. **Download Node.js**:

   - Visit the official Node.js website: [Node.js Website](https://nodejs.org/).
   - Download the 16.20.2 version

2. **Run the Installer**:

   - Double-click the downloaded installer file (e.g., `node-vXX.XX.X-x64.msi`).
   - Follow the installation wizard's instructions.
   - Accept the default settings unless you have specific preferences.

3. **Verify Installation**:
   - Open the Command Prompt (cmd.exe) or PowerShell.
   - Type the following commands to verify the installation:
     ```
     node -v
     npm -v
     ```
   - You should see the installed Node.js and npm (Node Package Manager) versions.

#### macOS:

1. **Using Homebrew (recommended)**:

   - If you have Homebrew installed, open your terminal and run the following command to install Node.js and npm:
     ```
     brew install node
     ```

2. **Download from the Node.js website**:

   - Visit the official Node.js website: [Node.js Website](https://nodejs.org/).
   - Download the 16.20.2 version for macOS.

3. **Run the Installer**:

   - Double-click the downloaded `.pkg` file and follow the installation instructions.

4. **Verify Installation**:
   - Open the Terminal.
   - Type the following commands to verify the installation:
     ```
     node -v
     npm -v
     ```
   - You should see the installed Node.js and npm versions.

After following these steps, you should have Node.js and npm installed on your system.

### Step 5 Clone Repository

Clone repository in desired Directory and navigate into the new "f24-iquest" folder.

### Step 6 Install Dependencies

Make sure to have all dependencies installed. You can install them with these commands: **(make sure that terminal is in iQuestApp Directory where the js files are.)**

```
npm install -g expo-cli
```

```
npm install
```

### Step 7 Run App

```
npx expo start
```

Scan QR from terminal with your mobile camera.
Expo Go should open with the app in it.

## Usage

You can create an account to the app and then login, you can add independence goals in a section (home or school) and mark them as completed to receive a certificate. You can also personalize the app UI and your profile

## License

MIT

[expo]: https://expo.dev/
[firebase]: https://firebase.google.com/
[node.js]: http://nodejs.org
